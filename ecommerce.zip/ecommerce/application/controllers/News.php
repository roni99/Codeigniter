<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller {

    function __construct() {

        parent::__construct();
        $this->load->model('FrontEndModel');
        $this->load->library('cart');
    }

    public function index() {
        $data = array();
        $data['demodata'] = 'NONE';
        $data['products'] = $this->db->get('tbl_product')->result();
        $data['page'] = 'frontend/index';
        $this->load->view('frontend/welcome', $data);
    }
    public function add_cart($param1='',$param2='',$param3='')
    {
        $id=$this->input->post('id',true);
        $qty=$this->input->post('qty',true);
        $values = $this->db->get_where('tbl_product',array('id'=>$id))->row();
        //var_dump($values);die;
        $data = array(
            'id' => $values->id,
            'qty'     => $qty,
            'price'   => $values->price,
            'name'    => $values->name,
            'image'   => $values->thumb_photo
        );
       //print '<pre>'; print_r($data);die;
        $insert = $this->cart->insert($data);
        if($insert)
        {
            redirect('News','fresh');
        }else{
            print 'ERROR-404';
        }
    }
    public function cart_delete($rowid)
    {
        $data = array(
            'rowid'   => $rowid,
            'qty'     => 0
        );

        $this->cart->update($data);
        redirect('News/cart_list');
    }
    public function cart_list($param1='',$param2='',$param3='')
    {
        $data = array();
        $data['demodata'] = 'NONE';
        $data['products'] = $this->db->get('tbl_product')->result();
        $data['page'] = 'frontend/cart_list';
        $this->load->view('frontend/welcome', $data);
    }
    public function registration($param1='',$param2='',$param3='')
    {
        if($param1 == 'customer_login'){
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                //echo "ok";die;
                $email     = $this->input->post('email');
                $password  = sha1($this->input->post('password'));

                $get_value = $this->db->get_where('user', array('email'=>$email,'password'=>$password,'userType'=>'user'))->row(); 
                //var_dump($get_value);die;

                if(count($get_value) > 0){
                    $this->session->set_userdata('user_id', $get_value->id);
                    redirect('News/payment');                   

                }else{
                    $this->session->set_flashdata('messages', 'Email or Password does not Match.');
                    redirect('News/registration');
                }
            }
        }
        if(isset($_SESSION['user_id'])){
            //redirect('News/payment');
        }

        $data               = array();
        $data['demodata']   = 'NONE';
        $data['page']       = 'frontend/customer_login';
        $this->load->view('frontend/welcome', $data);
    }
    public function payment($param1='',$param2='',$param3='')
    {
        if($_SERVER['REQUEST_METHOD']== 'POST' and $param1 == 'pay'){
            //$payment['']        = $this->input->post();

            $insert_invoice['user_id']        = $_SESSION['user_id'];
            $insert_invoice['amount']         = $this->cart->total();
            $insert_invoice['sales_date']     = date('Y-m-d');
            $insert_invoice['insert_time']    = date('Y-m-d h:i:s');

            $insert_done    = $this->db->insert('tbl_invoice',$insert_invoice);
            $last_insert_id = $this->db->insert_id();

            if($insert_done){
                $cart = $this->cart->contents();
                
                foreach ($cart as $value) {
                    $invoice['invoice_id']      = $last_insert_id;
                    $invoice['product_id']      = $value['id'];
                    $invoice['quantity']        = $value['qty'];

                    $this->db->insert('tbl_invoice_details',$invoice);
                }
                 $this->session->set_flashdata('messages', 'Your Order Successfully Done');
                 //$this->cart->remove();
            }else{
                print 'not insert';
            }
        }

        $data               = array();
        $data['demodata']   = 'NONE';
        $data['page']       = 'frontend/payment';
        $this->load->view('frontend/welcome', $data);
    }

}
