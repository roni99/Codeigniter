<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {

		parent::__construct();

		$this->lang->load('content', $_SESSION['lang']);

		if (!isset($_SESSION['user_auth']) || $_SESSION['user_auth'] != true) {
			redirect('login', 'refresh');
		}
		if ($_SESSION['userType'] != 'admin')
			redirect('login', 'refresh');
		//Model Loading
		$this->load->model('AdminModel');
		$this->load->library("pagination");
		$this->load->helper("url");
		$this->load->helper("text");

		date_default_timezone_set("Asia/Dhaka");
	}

	public function index() {
		
		$data['title']      = 'Admin Panel • HRSOFTBD News Portal Admin Panel';
		$data['page']       = 'backEnd/dashboard_view';
		$data['activeMenu'] = 'dashboard_view';
		
		
		$this->load->view('backEnd/master_page', $data);
	}

	public function add_user($param1 = '') {

		$messagePage['divissions'] = $this->db->get('tbl_divission')->result_array();
		$messagePage['userType']   = $this->db->get('user_type')->result_array();

		$messagePage['title']      = 'Add User Admin Panel • HRSOFTBD News Portal Admin Panel';
		$messagePage['page']       = 'backEnd/admin/add_user';
		$messagePage['activeMenu'] = 'add_user';
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

			$saveData['firstname'] = $this->input->post('first_name', true);
			$saveData['lastname']  = $this->input->post('last_name', true);
			$saveData['username']  = $this->input->post('user_name', true);
			$saveData['email']     = $this->input->post('email', true);
			$saveData['phone']     = $this->input->post('phone', true);
			$saveData['password']  = sha1($this->input->post('password', true));
			$saveData['address']   = $this->input->post('address', true);
			$saveData['roadHouse'] = $this->input->post('road_house', true);
			$saveData['userType']  = $this->input->post('user_type', true);
			$saveData['photo']     = 'assets/userPhoto/defaultUser.jpg';


			//This will returns as third parameter num_rows, result_array, result
			$username_check = $this->AdminModel->isRowExist('user', array('username' => $saveData['username']), 'num_rows');
			$email_check = $this->AdminModel->isRowExist('user', array('email' => $saveData['email']), 'num_rows');

			if ($username_check > 0 || $email_check > 0) {
				//Invalid message
				$messagePage['page'] = 'backEnd/admin/insertFailed';
				$messagePage['noteMessage'] = "<hr> UserName: " . $saveData['username'] . " can not be create.";
				if ($username_check > 0) {

					$messagePage['noteMessage'] .= '<br> Cause this username is already exist.';
				} else if ($email_check > 0) {

					$messagePage['noteMessage'] .= '<br> Cause this email is already exist.';
				}
			} else {
				//success
				$insertId = $this->AdminModel->saveDataInTable('user', $saveData, 'true');

				$messagePage['page'] 		= 'backEnd/admin/insertSuccessfull';
				$messagePage['noteMessage'] = "<hr> UserName: " . $saveData['username'] . " has been created successfully.";

				// Category allocate for users
				if (!empty($this->input->post('selectCategory', true))) {

					foreach ($this->input->post('selectCategory', true) as $cat_value) {

						$this->db->insert('category_user', array('userId' => $insertId, 'categoryId' => $cat_value));
					}
				}
			}
		}


		$this->load->view('backEnd/master_page', $messagePage);
	}

	public function edit_user($param1 = '') {
		// Update using post method 
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

			$saveData['firstname'] = $this->input->post('first_name', true);
			$saveData['lastname']  = $this->input->post('last_name', true);
			$saveData['phone']     = $this->input->post('phone', true);
			$saveData['address']   = $this->input->post('address', true);
			$saveData['roadHouse'] = $this->input->post('road_house', true);
			$saveData['userType']  = $this->input->post('user_type', true);
			$user_id               = $this->input->post('user_id', true);


			$this->db->where('id', $user_id);
			$this->db->update('user', $saveData);
			
			$data['page']          = 'backEnd/admin/insertSuccessfull';
			$data['noteMessage']   = "<hr> Data has been Updated successfully.";

		} else if ($this->AdminModel->isRowExist('user', array('id' => $param1), 'num_rows') > 0) {

			$data['userDetails']   = $this->AdminModel->isRowExist('user', array('id' => $param1), 'result_array');

			$myupozilla_id         = $this->db->get_where('tbl_upozilla', array("id"=>$data['userDetails'][0]['address']))->row();

			$data['myzilla_id']    = $myupozilla_id->zilla_id;
			$data['mydivision_id'] = $myupozilla_id->division_id;

			$data['divissions']    = $this->db->get('tbl_divission')->result();
		
			$data['distrcts']      = $this->db->get_where('tbl_zilla',array('divission_id'=>$data['mydivision_id']))->result();
			$data['upozilla']      = $this->db->get_where('tbl_upozilla',array('zilla_id'=>$data['myzilla_id']))->result();

			$data['userType'] = $this->db->get('user_type')->result_array();
			$data['user_id']  = $param1;
			$data['page']     = 'backEnd/admin/edit_user';

		} else {

			$data['page']        = 'errors/invalidInformationPage';
			$data['noteMessage'] = $this->lang->line('wrong_info_search');
		}
		
		$data['title']      = 'Users List Admin Panel • HRSOFTBD News Portal Admin Panel';
		$data['activeMenu'] = 'user_list';
		$this->load->view('backEnd/master_page', $data);
	}

	public function suspend_user($id, $setvalue) {

		$this->db->where('id', $id);
		$this->db->update('user', array('status' => $setvalue));
		$this->session->set_flashdata('message', 'Data Saved Successfully.');
		redirect('admin/user_list', 'refresh');
	}

	public function delete_user($id) {

		$old_image_url=$this->db->where('id', $id)->get('user')->row();
		$this->db->where('id', $id)->delete('user');
		if(isset($old_image_url->photo)){
			unlink($old_image_url->photo);
		}

		$this->session->set_flashdata('message', 'Data Deleted.');
		redirect('admin/user_list', 'refresh');
	}

	public function user_list() {

		$this->db->where('userType !=', 'admin');
		$data['myUsers']    = $this->db->get('user')->result_array();
		$data['title']      = 'Users List Admin Panel • HRSOFTBD News Portal Admin Panel';
		$data['page']       = 'backEnd/admin/user_list';
		$data['activeMenu'] = 'user_list';
		$this->load->view('backEnd/master_page', $data);
	}

	public function image_size_fix($filename, $width = 600, $height = 400, $destination = '') {

		// Content type
		// header('Content-Type: image/jpeg');
		// Get new dimensions
		list($width_orig, $height_orig) = getimagesize($filename);

		// Output 20 May, 2018 updated below part
		if ($destination == '' || $destination == null)
			$destination = $filename;

		$extention = pathinfo($destination, PATHINFO_EXTENSION);
		if ($extention != "png" && $extention != "PNG" && $extention != "JPEG" && $extention != "jpeg" && $extention != "jpg" && $extention != "JPG") { 
			return true;
		}
		// Resample
		$image_p = imagecreatetruecolor($width, $height);
		$image   = imagecreatefromstring(file_get_contents($filename));
		imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);

		

		if ($extention == "png" || $extention == "PNG") {
			imagepng($image_p, $destination, 9);
		} else if ($extention == "jpg" || $extention == "JPG" || $extention == "jpeg" || $extention == "JPEG") {
			imagejpeg($image_p, $destination, 70);
		} else {
			imagepng($image_p, $destination);
		}
		return true;
	}

	public function get_division() {

		$result = $this->db->select('id, name')->get('tbl_divission')->result();
		echo json_encode($result, JSON_UNESCAPED_UNICODE);
	}

	public function get_zilla_from_division($division_id = 1) {

		$result = $this->db->select('id, name')->where('divission_id', $division_id)->get('tbl_zilla')->result();
		echo json_encode($result, JSON_UNESCAPED_UNICODE);
	}

	public function get_upozilla_from_division_zilla($zilla_id = 1) {

		$result = $this->db->select('id, name')->where('zilla_id', $zilla_id)->get('tbl_upozilla')->result();
		echo json_encode($result, JSON_UNESCAPED_UNICODE);
	}

	public function download_file($file_name = '', $fullpath='') {

		// echo $file_name; exit();
		$filePath = 'assets/ebookDocument/' . $file_name;

		if($file_name=='full' && ($fullpath != '' || $fullpath != null)) $filePath = $fullpath;

		if($_GET['file_path']) $filePath = $_GET['file_path'];
		// echo $filePath; exit();
		if (file_exists($filePath)) {
			$fileName = basename($filePath);
			$fileSize = filesize($filePath);

			// Output headers.
			header("Cache-Control: private");
			header("Content-Type: application/stream");
			header("Content-Length: " . $fileSize);
			header("Content-Disposition: attachment; filename=" . $fileName);

			// Output file.
			readfile($filePath);
			exit();
		} else {
			die('The provided file path is not valid.');
		}
	}
	
	public function profile($param1 = '')
	{

		$user_id            = $this->session->userdata('userid');
		$data['user_info']  = $this->AdminModel->get_user($user_id);


		$myzilla_id         = $data['user_info']->zilla_id;
		$mydivision_id      = $data['user_info']->division_id;

		$data['divissions'] = $this->db->get('tbl_divission')->result();

		$data['distrcts']   = $this->db->get_where('tbl_zilla', array('divission_id' => $mydivision_id))->result();
		$data['upozilla']   = $this->db->get_where('tbl_upozilla', array('zilla_id'  => $myzilla_id))->result();

		if ($param1 == 'update_photo') {

			if ($_SERVER['REQUEST_METHOD'] == 'POST') {			    
			    
			    //exta work
                $path_parts               = pathinfo($_FILES["photo"]['name']);
                $newfile_name             = preg_replace('/[^A-Za-z]/', "", $path_parts['filename']);
                $dir                      = date("YmdHis", time());
                $config['file_name']      = $newfile_name . '_' . $dir;
                $config['remove_spaces']  = TRUE;
                //exta work
                $config['upload_path']    = 'assets/userPhoto/';
                $config['max_size']       = '20000'; //  less than 20 MB
                $config['allowed_types']  = 'jpg|png|jpeg|jpg|JPG|JPG|PNG|JPEG';

                $this->load->library('upload', $config);

                if (!$this->upload->do_upload('photo')) {

                    // case - failure
					$upload_error = array('error' => $this->upload->display_errors());
					$this->session->set_flashdata('message', "Failed to update image.");

                } else {

                    $upload                 = $this->upload->data();
                    $newphotoadd['photo']   = $config['upload_path'] . $upload['file_name'];

                    $old_photo              = $this->db->where('id', $user_id)->get('user')->row()->photo;
                    
                    if(file_exists($old_photo)) unlink($old_photo);

                    $this->image_size_fix($newphotoadd['photo'], 200, 200);

                    $this->db->where('id', $user_id)->update('user', $newphotoadd);

                    $this->session->set_userdata('userPhoto', $newphotoadd['photo']);
					$this->session->set_flashdata('message', 'User Photo Updated Successfully!');
					
					redirect('admin/profile','refresh');
                }
                
			  }
			  
		}else if($param1 == 'update_pass'){

		   if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		       
			   $old_pass    = sha1($this->input->post('old_pass', true)); 
			   $new_pass    = sha1($this->input->post('new_pass', true)); 
			   $user_id     = $this->session->userdata('userid');

			   $get_user    = $this->db->get_where('user',array('id'=>$user_id, 'password'=>$old_pass));
			   $user_exist  = $get_user->row();

			   if($user_exist){
			       
					$this->db->where('id',$user_id)
							->update('user',array('password'=>$new_pass));
					$this->session->set_flashdata('message', 'Password Updated Successfully');
					redirect('admin/profile','refresh');
					
			   }else{
			       
				    $this->session->set_flashdata('message', 'Password Update Failed');
				    redirect('admin/profile','refresh');
				   
			   }
			   
			}
			
		}else if($param1 == 'update_info'){

			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			    
				$update_data['firstname']   = $this->input->post('firstname', true);
				$update_data['lastname']    = $this->input->post('lastname', true);
				$update_data['roadHouse']   = $this->input->post('roadHouse', true);
				$update_data['address']     = $this->input->post('address', true);


				$db_email     = $this->db->where('id!=', $user_id)->where('email', $this->input->post('email', true))->get('user')->num_rows();
				$db_username  = $this->db->where('id!=', $user_id)->where('username', $this->input->post('username', true))->get('user')->num_rows();


				if ( $db_username == 0) {

					 $update_data['username']    = $this->input->post('username', true);
					 
				}if ( $db_email == 0) {

					 $update_data['email']       = $this->input->post('email', true);
					 
				}
				

    			if ($this->AdminModel->update_pro_info($update_data, $user_id)) {
    			    
    			    $this->session->set_userdata('username_first', $update_data['firstname']);
    			    $this->session->set_userdata('username_last', $update_data['lastname']);
    			    $this->session->set_userdata('username', $update_data['username']);
    			    
    				$this->session->set_flashdata('message', 'Information Updated Successfully!');
    				redirect('admin/profile', 'refresh');
    				
    			} else {
    			    
    				$this->session->set_flashdata('message', 'Information Update Failed!');
    				redirect('admin/profile', 'refresh');
    				
    			} 
				
			}
		}
		
		$data['title']      = 'Profile Admin Panel • HRSOFTBD News Portal Admin Panel';
		$data['activeMenu'] = 'Profile';
		$data['page']       = 'backEnd/admin/profile';
		
		$this->load->view('backEnd/master_page',$data);
	}

    public function category($param1='',$param2='',$param3='')
    {
    	if($param1 == 'add'){
	    		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$insert_category['name_bn']        = $this->input->post('name_bn', true);
	    			$insert_category['name_en']        = $this->input->post('name_en', true);
	    			$insert_category['url_make']       = $this->input->post('url_make', true);
	    			$insert_category['parent_id']      = $this->input->post('parent_id', true);
	    			$insert_category['priority']       = $this->input->post('priority', true);
	    			$insert_category['insert_by']	   = $_SESSION['userid'];
	    			$insert_category['insert_time']	   = date('Y:m:d H:m:s');

					$add_category = $this->db->insert('tbl_category',$insert_category);

					if ($add_category) {

						$this->session->set_flashdata('message',"Category Added Successfully!");
						redirect('admin/category/add','refresh');

					} else {
						$this->session->set_flashdata('message',"Category Add Failed");
						redirect('admin/category/add','refresh');
					}

	    		}

    		$data['title'] 		= 'Category';
	    	$data['activeMenu'] = 'category_add';
	    	$data['page'] 		= 'backEnd/admin/category_add';
	    	$data['category']	= $this->db->get_where('tbl_category',array('parent_id'=>'0'))->result_array();
	    	$this->load->view('backEnd/master_page',$data);

    	}
    	elseif($param1 == 'edit' && $param2 > 0){

    		$data['edit_info'] = $this->db->get_where('tbl_category',array('id'=>$param2));
    		if ($data['edit_info']->num_rows() > 0) {

    			$data['edit_info']    = $data['edit_info']->row();
    			$data['edit_info_id'] = $param2;

    			if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$update_category['name_bn']        = $this->input->post('name_bn', true);
	    			$update_category['name_en']        = $this->input->post('name_en', true);
	    			$update_category['url_make']       = $this->input->post('url_make', true);
	    			$update_category['parent_id']      = $this->input->post('parent_id', true);
	    			$update_category['priority']       = $this->input->post('priority', true);

					if ($this->AdminModel->category_update($update_category,$param2)) {

						$this->session->set_flashdata('message',"Category Updated Successfully!");
						redirect('admin/category/edit/'.$param2,'refresh');

					} else {

						$this->session->set_flashdata('message',"Category Update Failed");
						redirect('admin/category/edit/'.$param2,'refresh');
					}

	    		}
	    		$data['title'] = 'Category';
		    	$data['activeMenu'] = 'category_edit';
		    	$data['page'] = 'backEnd/admin/category_edit';
		    	$data['category']	= $this->db->get_where('tbl_category',array('parent_id'=>'0'))->result_array();
		    	$this->load->view('backEnd/master_page',$data);

    		} else {

    			$this->session->set_flashdata('message',"Wrong Attempt!");
				redirect('admin/category/list','refresh');

    		}
    	}
    	elseif($param1 == 'delete' && $param2 > 0){
    		if ($this->AdminModel->category_delete($param2)) {

						$this->session->set_flashdata('message',"Category Deleted Successfully!");
						redirect('admin/category/list','refresh');

					} else {

						$this->session->set_flashdata('message',"Category Delete Failed");
						redirect('admin/category/list','refresh');
					}
    	}

    	elseif($param1 == 'list'){
    	$data['title'] = 'Category';
    	$data['activeMenu'] = 'category_list';
    	$data['page'] = 'backEnd/admin/category_list';
    	$data['category'] = $this->db->order_by('priority','desc')->get('tbl_category')->result();
    	$this->load->view('backEnd/master_page',$data);
    	}

    	
    }
    public function delivery_policy($param1='',$param2='',$param3='')
    {
    	if($param1 == 'add'){
	    		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$insert_policy['area']        = $this->input->post('area', true);
	    			$insert_policy['day']        = $this->input->post('days', true);
	    			$insert_policy['cost']       = $this->input->post('cost', true);
	    			$insert_policy['insert_by']	   = $_SESSION['userid'];
	    			$insert_policy['insert_time']	   = date('Y:m:d H:m:s');

					$add_delivary_policy = $this->db->insert('tbl_delivary_policy',$insert_policy);

					if ($add_delivary_policy) {

						$this->session->set_flashdata('message',"Delivery Policy Added Successfully!");
						redirect('admin/delivery_policy/add','refresh');

					} else {
						$this->session->set_flashdata('message',"Delivery Policy Add Failed");
						redirect('admin/delivery_policy/add','refresh');
					}

	    		}

    		$data['title'] 		= 'Delivery Policy';
	    	$data['activeMenu'] = 'delivery_policy_add';
	    	$data['page'] 		= 'backEnd/admin/delivery_policy_add';
	    	$this->load->view('backEnd/master_page',$data);

    	}
    	elseif($param1 == 'edit' && $param2 > 0){

    		$data['edit_info'] = $this->db->get_where('tbl_delivary_policy',array('id'=>$param2));
    		if ($data['edit_info']->num_rows() > 0) {

    			$data['edit_info']    = $data['edit_info']->row();
    			$data['edit_info_id'] = $param2;

    			if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$update_policy['area']        = $this->input->post('area', true);
	    			$update_policy['day']        = $this->input->post('days', true);
	    			$update_policy['cost']       = $this->input->post('cost', true);

					if ($this->AdminModel->delivery_policy_update($update_policy,$param2)) {

						$this->session->set_flashdata('message',"Delivery Policy Updated Successfully!");
						redirect('admin/delivery_policy/edit/'.$param2,'refresh');

					} else {

						$this->session->set_flashdata('message',"Delivery Policy Update Failed");
						redirect('admin/delivery_policy/edit/'.$param2,'refresh');
					}

	    		}
	    		$data['title'] = 'delivery policy';
		    	$data['activeMenu'] = 'delivery_policy_edit';
		    	$data['page'] = 'backEnd/admin/delivery_policy_edit';
		  
		    	$this->load->view('backEnd/master_page',$data);

    		} else {

    			$this->session->set_flashdata('message',"Wrong Attempt!");
				redirect('admin/delivery_policy/list','refresh');

    		}
    	}
    	elseif($param1 == 'delete' && $param2 > 0){
    		if ($this->AdminModel->delivery_policy_delete($param2)) {

						$this->session->set_flashdata('message',"Delivery Policy Deleted Successfully!");
						redirect('admin/delivery_policy/list','refresh');

					} else {

						$this->session->set_flashdata('message',"Delivery Policy Delete Failed");
						redirect('admin/delivery_policy/list','refresh');
					}
    	}

    	elseif($param1 == 'list'){

    	$data['title'] 			= 'Delivery Policy';
    	$data['activeMenu'] 	= 'delivery_policy_list';
    	$data['page'] 			= 'backEnd/admin/delivery_policy_list';
    	$data['delivery_policy']= $this->db->get('tbl_delivary_policy')->result();
    	$this->load->view('backEnd/master_page',$data);

    	}

    	
    }
    public function term_policy($param1='',$param2='',$param3='')
    {
    	if($param1 == 'add'){
	    		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$insert_policy['title']        = $this->input->post('title', true);
	    			$insert_policy['body']        = $this->input->post('body', true);
	    			$insert_policy['insert_by']	   = $_SESSION['userid'];
	    			$insert_policy['insert_time']	   = date('Y:m:d H:m:s');

					$add_term_policy = $this->db->insert('tbl_tearm_policy',$insert_policy);

					if ($add_term_policy) {

						$this->session->set_flashdata('message',"Term Policy Added Successfully!");
						redirect('admin/term_policy/add','refresh');

					} else {
						$this->session->set_flashdata('message',"Term Policy Add Failed");
						redirect('admin/term_policy/add','refresh');
					}

	    		}

    		$data['title'] 		= 'Term Policy';
	    	$data['activeMenu'] = 'term_policy_add';
	    	$data['page'] 		= 'backEnd/admin/term_policy_add';
	    	$this->load->view('backEnd/master_page',$data);

    	}
    	elseif($param1 == 'edit' && $param2 > 0){

    		$data['edit_info'] = $this->db->get_where('tbl_tearm_policy',array('id'=>$param2));
    		if ($data['edit_info']->num_rows() > 0) {

    			$data['edit_info']    = $data['edit_info']->row();
    			$data['edit_info_id'] = $param2;

    			if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	    			$update_policy['title']       = $this->input->post('title', true);
	    			$update_policy['body']        = $this->input->post('body', true);

					if ($this->AdminModel->term_policy_update($update_policy,$param2)) {

						$this->session->set_flashdata('message',"Term Updated Successfully!");
						redirect('admin/term_policy/edit/'.$param2,'refresh');

					} else {

						$this->session->set_flashdata('message',"Term Update Failed");
						redirect('admin/term_policy/edit/'.$param2,'refresh');
					}

	    		}
	    		$data['title'] = 'delivery policy';
		    	$data['activeMenu'] = 'term_policy_edit';
		    	$data['page'] = 'backEnd/admin/term_policy_edit';
		  
		    	$this->load->view('backEnd/master_page',$data);

    		} else {

    			$this->session->set_flashdata('message',"Wrong Attempt!");
				redirect('admin/term_policy/list','refresh');

    		}
    	}
    	elseif($param1 == 'delete' && $param2 > 0){
    		if ($this->AdminModel->term_policy_delete($param2)) {

				$this->session->set_flashdata('message',"Term Policy Deleted Successfully!");
				redirect('admin/term_policy/list','refresh');

			} else {

				$this->session->set_flashdata('message',"Term Policy Delete Failed");
				redirect('admin/term_policy/list','refresh');
			}
    	}

    	elseif($param1 == 'list'){

    	$data['title'] 			= 'Term Policy';
    	$data['activeMenu'] 	= 'term_policy_list';
    	$data['page'] 			= 'backEnd/admin/term_policy_list';
    	$data['term_policy']	= $this->db->get('tbl_tearm_policy')->result();
    	$this->load->view('backEnd/master_page',$data);

    	}

    	
    }
    public function product($param1='',$param2='',$param3='')
    {
    	if($param1 == 'add'){
    		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    			$insert_product['name']        	 = $this->input->post('product_name', true);
    			$insert_product['url_generate']  = $this->input->post('product_url', true);
    			$insert_product['product_code']	 = $this->input->post('product_code',true);
    			$insert_product['quantity']		 = $this->input->post('product_qty',true);
    			$insert_product['price']		 = $this->input->post('product_price',true);

    			$insert_product['colors']		 = $this->input->post('product_color',true);
    			//$insert_product['size']		 	 = $this->input->post('product_size');
    			$insert_product['size'] 		 = array();
    			
    			$insert_product['size'] 		 = implode(',', $this->input->post('product_size', true));

    			$insert_product['brand']		 = $this->input->post('product_brand', true);
    			$insert_product['description']	 = $this->input->post('product_desc', true);

    			$insert_product['insert_by']     = $_SESSION['userid'];
    			$insert_product['insert_time']   = date('Y:m:d H:m:s');

    			// Thumb photo upload //
    			if (!empty($_FILES["product_thumbphoto"]['name'])){

					//exta work
					$path_parts                 = pathinfo($_FILES["product_thumbphoto"]['name']);
					$newfile_name               = preg_replace('/[^A-Za-z]/', "", $path_parts['filename']);
					$dir                        = date("YmdHis", time());
					$config_c['file_name']      = $newfile_name . '_' . $dir;
					$config_c['remove_spaces']  = TRUE;
					$config_c['upload_path']    = 'assets/productThumbphoto/';
					$config_c['max_size']       = '20000'; //  less than 20 MB
					$config_c['allowed_types']  = 'jpg|png|jpeg|jpg|JPG|JPG|PNG|JPEG';

					$this->load->library('upload', $config_c);
					$this->upload->initialize($config_c);
					if (!$this->upload->do_upload('product_thumbphoto')) {

					} else {

						$upload_c = $this->upload->data();
						$insert_product['thumb_photo'] = $config_c['upload_path'] . $upload_c['file_name'];
						$this->image_size_fix($insert_product['thumb_photo'], 400, 400);
					}
				}
    			

				$add_product = $this->db->insert('tbl_product',$insert_product);
				$last_id = $this->db->insert_id();
				
				if ($add_product) {
					// upload product photo //
					if (!empty($_FILES["product_photo"]['name'])){
						$config_c['remove_spaces']  = TRUE;
						$config_c['upload_path']    = 'assets/productPhoto/';
						$config_c['max_size']       = '20000'; //  less than 20 MB
						$config_c['allowed_types']  = 'jpg|png|jpeg|jpg|JPG|JPG|PNG|JPEG';

						$this->load->library('upload');

						$files = $_FILES;
						for($i=0; $i< count($files['product_photo']['name']); $i++)
						{           
							$_FILES['product_photo']['name']     = $files['product_photo']['name'][$i];
							$_FILES['product_photo']['type']     = $files['product_photo']['type'][$i];
							$_FILES['product_photo']['tmp_name'] = $files['product_photo']['tmp_name'][$i];
							$_FILES['product_photo']['error']    = $files['product_photo']['error'][$i];
							$_FILES['product_photo']['size']     = $files['product_photo']['size'][$i]; 

							$path_parts                 		 = pathinfo($_FILES['product_photo']['name']);
							$newfile_name                        = preg_replace('/[^A-Za-z]/', "", $path_parts['filename']);
							$dir                        		 = date("YmdHis", time());
							$config_c['file_name']      		 = $newfile_name . '_' . $dir;


							$this->upload->initialize($config_c);
							if (!$this->upload->do_upload('product_photo')) {

							} else {
								$upload_c = $this->upload->data();
								$insert_photo['photo'] = $config_c['upload_path'] . $upload_c['file_name'];
								$this->image_size_fix($insert_photo['photo'], 400, 400);

								//$success_photo = $this->AdminModel->create_successcase('tbl_success_case_photo',$insert_success_photo);
								$insert_photo['product_id']	   = $last_id;
								$insert_photo['type']	   	   = 'Promotion';
								$insert_photo['insert_by']     = $_SESSION['userid'];
    							$insert_photo['insert_time']   = date('Y:m:d H:m:s');
								$this->db->insert('tbl_product_photo',$insert_photo);
							}    
						}

					}
					// end product photo //

					// upload video link //
					if(!empty($this->input->post('product_video_link', true)))
					{
						$insert_video['product_id']	   = $last_id;						
						$insert_video['video_path']    = $this->input->post('product_video_link', true);
						$this->db->insert('tbl_product_video',$insert_video);
					}
					// end video link //

					// product delivery policy //
					$delivery_policy = array();
					$delivery_policy = $this->input->post('delivery_policy',true);

					foreach($delivery_policy as $delivery_policy_value ){ 
						//var_dump($delivery_policy);die;
						$insert_delivery['product_id']     		 = $last_id;
						$insert_delivery['delivary_policy_id']   = $delivery_policy_value;

						$this->db->insert('tbl_product_delivary_policy',$insert_delivery);
					}
					// end product delivery policy //

					// category part //
					$category = array();
					$category = $this->input->post('category',true);

					foreach($category as $category_value ){ 
						//var_dump($delivery_policy);die;
						$insert_category['product_id']    = $last_id;
						$insert_category['category_id']   = $category_value;

						$this->db->insert('tbl_product_category',$insert_category);
					}

					$this->session->set_flashdata('message',"Product Added Successfully!");
					redirect('admin/product/add','refresh');

				} else {
					$this->session->set_flashdata('message',"Product Add Failed");
					redirect('admin/product/add','refresh');
				}

    		}

    		$data['title'] 		= 'Manage Product';
	    	$data['activeMenu'] = 'product_add';
	    	$data['page'] 		= 'backEnd/admin/product_add';
	    	$this->load->view('backEnd/master_page',$data);
    	}
    	elseif($param1 == 'edit' and $param2 > 0){
    		if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    			$update_product['name']        	 = $this->input->post('product_name', true);
    			$update_product['url_generate']  = $this->input->post('product_url', true);
    			$update_product['product_code']	 = $this->input->post('product_code',true);
    			$update_product['quantity']		 = $this->input->post('product_qty',true);
    			$update_product['price']		 = $this->input->post('product_price',true);

    			$update_product['colors']		 = $this->input->post('product_color',true);
    			//$insert_product['size']		 	 = $this->input->post('product_size');
    			$update_product['size'] = array();
    			
    			$update_product['size'] = implode(',', $this->input->post('product_size', true));

    			$update_product['brand']		 = $this->input->post('product_brand', true);
    			$update_product['description']	 = $this->input->post('product_desc', true);

    			$update_product['insert_by']     = $_SESSION['userid'];
    			$update_product['insert_time']   = date('Y:m:d H:m:s');

    			// Thumb photo upload //
    			if (!empty($_FILES["product_thumbphoto"]['name'])){

					//exta work
					$path_parts                 = pathinfo($_FILES["product_thumbphoto"]['name']);
					$newfile_name               = preg_replace('/[^A-Za-z]/', "", $path_parts['filename']);
					$dir                        = date("YmdHis", time());
					$config_c['file_name']      = $newfile_name . '_' . $dir;
					$config_c['remove_spaces']  = TRUE;
					$config_c['upload_path']    = 'assets/productThumbphoto/';
					$config_c['max_size']       = '20000'; //  less than 20 MB
					$config_c['allowed_types']  = 'jpg|png|jpeg|jpg|JPG|JPG|PNG|JPEG';

					$this->load->library('upload', $config_c);
					$this->upload->initialize($config_c);
					if (!$this->upload->do_upload('product_thumbphoto')) {

					} else {

						$upload_c = $this->upload->data();
						$update_product['thumb_photo'] = $config_c['upload_path'] . $upload_c['file_name'];
						$this->image_size_fix($update_product['thumb_photo'], 400, 400);
					}

						$get_thumbphoto = $this->db->select('thumb_photo')
											->get_where('tbl_product',array('id'=>$param2))
											->row()->thumb_photo;
						if (file_exists($get_thumbphoto)) {

							unlink($get_thumbphoto);

						}
					
				}
    			

				$update_product = $this->db->where('id',$param2)->update('tbl_product',$update_product);
				$update_id = $param2;
				
				if ($update_product) {

					// upload video link //
					if(!empty($this->input->post('product_video_link', true)))
					{
						$update_video['product_id']	   = $update_id;						
						$update_video['video_path']    = $this->input->post('product_video_link', true);
						$this->db->where('product_id',$param2)->update('tbl_product_video',$update_video);
					}
					// end video link //

					// product delivery policy //
					$delivery_policy = array();
					$delivery_policy = $this->input->post('delivery_policy',true);
					$this->db->where('product_id',$param2)->delete('tbl_product_delivary_policy');
					foreach($delivery_policy as $delivery_policy_value ){ 
					
						$insert_delivery['product_id']     		 = $update_id;
						$insert_delivery['delivary_policy_id']   = $delivery_policy_value;

						$this->db->insert('tbl_product_delivary_policy',$insert_delivery);
					}
					// end product delivery policy //

					// category part //
					$category = array();
					$category = $this->input->post('category',true);
					$this->db->where('product_id',$param2)->delete('tbl_product_category');
					foreach($category as $category_value ){ 
						//var_dump($delivery_policy);die;
						$insert_category['product_id']    = $update_id;
						$insert_category['category_id']   = $category_value;

						$this->db->insert('tbl_product_category',$insert_category);
					}

					$this->session->set_flashdata('message',"Product Updated Successfully!");
					redirect('admin/product/edit/'.$param2,'refresh');

				} else {
					$this->session->set_flashdata('message',"Product Updated Failed");
					redirect('admin/product/edit/'.$param2,'refresh');
				}

    		}
    		// end edit

    		$data['product']					= $this->db->get_where('tbl_product',array('id'=>$param2))->row();
    		$select_product_photo				= $this->db->get_where('tbl_product_photo',array('product_id'=>$param2))->result();

    		$data['select_product_photo']		= array();

    		foreach ($select_product_photo as $select_value) {
    			array_push($data['select_product_photo'],$select_value);
    		}

    		$data['all_category'] 				= $this->db->get('tbl_category')->result();

			$select_product_category_id 		= $this->db->get_where('tbl_product_category', array("product_id"=>$data['product']->id))->result(); 
			
			$data['select_product_category_id'] = array();

			foreach ($select_product_category_id as $selected_value) {
				array_push($data['select_product_category_id'], $selected_value->category_id);
			}
			
			$data['all_delivery_policy'] = $this->db->get('tbl_delivary_policy')->result();

			$select_product_delivary_policy_id 	= $this->db->get_where('tbl_product_delivary_policy', array("product_id"=>$data['product']->id))->result();
			
			$data['select_product_delivary_policy_id'] = array();

			foreach ($select_product_delivary_policy_id as $select_delivery_policy) {
				 array_push($data['select_product_delivary_policy_id'], $select_delivery_policy->delivary_policy_id);
			}
			
			$data['product_video_link']     	= $this->db->get_where('tbl_product_video', array("product_id"=>$data['product']->id))->row();

    		$data['title'] 		    = 'Manage Product';
	    	$data['activeMenu']     = 'product_edit';
	    	$data['page'] 		    = 'backEnd/admin/product_edit';
	    	
	    	$this->load->view('backEnd/master_page',$data);
    	}
    	elseif($param1='delete' and $param2 > 0){
    		if ($this->AdminModel->product_delete($param2)) {
				$this->session->set_flashdata('message',"Product Deleted Successfully!");
				redirect('admin/product/list','refresh');

			} else {
				$this->session->set_flashdata('message',"Product Delete Failed");
				redirect('admin/product/list','refresh');
			}
    	}    	
    	else{
			$data['title'] 		= 'Manage Product';
	    	$data['activeMenu'] = 'product_list';
	    	$data['page'] 		= 'backEnd/admin/product_list';
	    	$data['products']	= $this->AdminModel->product();
	    	//print '<pre>'; print_r($data['products']);die;
	    	$this->load->view('backEnd/master_page',$data);  
	    }   	
    }
    public function product_photo($param1='',$param2='',$param3='')
    {
    	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    		    			// Thumb photo upload //
			if (!empty($_FILES["product_photo"]['name'])){

				//exta work
				$path_parts                 = pathinfo($_FILES["product_photo"]['name']);
				$newfile_name               = preg_replace('/[^A-Za-z]/', "", $path_parts['filename']);
				$dir                        = date("YmdHis", time());
				$config_c['file_name']      = $newfile_name . '_' . $dir;
				$config_c['remove_spaces']  = TRUE;
				$config_c['upload_path']    = 'assets/productPhoto/';
				$config_c['max_size']       = '20000'; //  less than 20 MB
				$config_c['allowed_types']  = 'jpg|png|jpeg|jpg|JPG|JPG|PNG|JPEG';

				$this->load->library('upload', $config_c);
				$this->upload->initialize($config_c);
				if (!$this->upload->do_upload('product_photo')) {

				} else {

					$upload_c 					 = $this->upload->data();
					$product_photo['product_id'] = $param1; 
					$product_photo['insert_by']  = $_SESSION['userid'];
					$product_photo['insert_time']= date('Y:m:d H:i:s');;
					$product_photo['photo'] 	 = $config_c['upload_path'] . $upload_c['file_name'];
					$this->image_size_fix($product_photo['photo'], 400, 400);
				}
				
			}
			$insert_photo = $this->db->insert('tbl_product_photo',$product_photo);
			if($insert_photo){
				$this->session->set_flashdata('message',"Photo Uploaded Successfully!");
				redirect('admin/product/edit/'.$param1,'refresh');
			}else{
				$this->session->set_flashdata('message',"Photo Uploaded Failed!");
				redirect('admin/product/edit/'.$param1,'refresh');
			}
    	}

    	$get_photo = $this->db->select('photo')
							  ->get_where('tbl_product_photo',array('id'=>$param2))
							  ->row()->photo;

			if (file_exists($get_photo)) {
				unlink($get_photo);
			}

			$delete = $this->db->where('id',$photo_id)->delete('tbl_product_photo');

			if($delete){
				$this->session->set_flashdata('message',"Photo Deleted Successfully!");
				redirect('admin/product/edit/'.$param1,'refresh');
			}else{
				$this->session->set_flashdata('message',"Photo Delete Failed!");
				redirect('admin/product/edit/'.$param1,'refresh');
			}
    }
    public function product_offer($param1='',$param2='',$param3=''){
    	if($param1 == 'add'){
    		if($_SERVER['REQUEST_METHOD'] == 'POST'){

    			$insert_product_offer['start_date'] 		= $this->input->post('start_date');
    			$insert_product_offer['end_date'] 			= $this->input->post('end_date');
    			$insert_product_offer['discount_percent']   = $this->input->post('discount');
    			$insert_product_offer['insert_by']  		= $_SESSION['userid'];
    			$insert_product_offer['insert_time']		= date('Y:m:d H:m:s');
    			$product_id 								= array();
    			$product_id									= $this->input->post('product');

    			foreach ($product_id as $product_list) {
    				$insert_product_offer['product_id']  	= $product_list;
    				$insert_done = $this->db->insert('tbl_product_offer',$insert_product_offer);

    				if($insert_done){
						$this->session->set_flashdata('message',"Product Offer Uploaded Successfully!");
						redirect('admin/product_offer/add/');
					}else{
						$this->session->set_flashdata('message',"Product Offer Upoloaded Failed!");
						redirect('admin/product_offer/add/');
					}
    			} // end foreach
    			
    		}

    		$all_product			= $this->db->get('tbl_product')->result();
    		$data['all_product']	= array();
    		foreach ($all_product as $all_product_value) {
    			array_push($data['all_product'],$all_product_value);
    		}
    		$data['title'] 			= 'Manage Product Offer';
	    	$data['activeMenu'] 	= 'product_offer_add';
	    	$data['page'] 			= 'backEnd/admin/product_offer_add';

	    	$this->load->view('backEnd/master_page',$data); 

    	}elseif($param1 == 'edit' and $param2 > 0){

    		if($_SERVER['REQUEST_METHOD'] == 'POST' and $param2 > 0){
    			$update_product_offer['start_date'] 		= $this->input->post('start_date');
    			$update_product_offer['end_date'] 			= $this->input->post('end_date');
    			$update_product_offer['discount_percent']   = $this->input->post('discount');
    			$update_product_offer['product_id']   		= $this->input->post('product');
    			$update_product_offer['insert_by']  		= $_SESSION['userid'];
    			$update_product_offer['insert_time']		= date('Y:m:d H:m:s');
    			
				$update_done = $this->db->where('id',$param2)->update('tbl_product_offer',$update_product_offer);

				if($update_done){
					$this->session->set_flashdata('message',"Product Offer Updated Successfully!");
					redirect('admin/product_offer/edit/'.$param2);
				}else{
					$this->session->set_flashdata('message',"Product Offer Updated Failed!");
					redirect('admin/product_offer/edit/'.$param2);
				}
    		}
    		//end edit

    		$data['single_product_offer']	= $this->db->get_where('tbl_product_offer',array('id'=>$param2))->row();

    		$all_product			= $this->db->get('tbl_product')->result();
    		$data['all_product']	= array();
    		foreach ($all_product as $all_product_value) {
    			array_push($data['all_product'],$all_product_value);
    		}
    		$all_product_offer		= $this->db->select('product_id')->get('tbl_product_offer')->result();

    		$data['all_product_offer']	= array();
    		foreach ($all_product_offer as $all_product_offer_value) {
    			array_push($data['all_product_offer'],$all_product_offer_value);
    		}

    		$data['title'] 			= 'Manage Product Offer';
	    	$data['activeMenu'] 	= 'product_offer_edit';
	    	$data['page'] 			= 'backEnd/admin/product_offer_edit';

	    	$this->load->view('backEnd/master_page',$data); 

    	}elseif($param1 == 'delete' and $param2 > 0){
    		if ($this->AdminModel->product_offer_delete($param2)) {
				$this->session->set_flashdata('message',"Product Offer Deleted Successfully!");
				redirect('admin/product_offer/list','refresh');

			} else {
				$this->session->set_flashdata('message',"Product Offer Delete Failed");
				redirect('admin/product_offer/list','refresh');
			}
    	}
    	else{
	    	$data['title'] 			= 'Manage Product Offer';
	    	$data['activeMenu'] 	= 'product_offer_list';
	    	$data['page'] 			= 'backEnd/admin/product_offer_list';
	    	$data['product_offer']	= $this->AdminModel->product_offer_list();
	
	    	$this->load->view('backEnd/master_page',$data);
	    } 
    }
    public function product_order($param1='',$param2='',$param3='')
    {
    	if($param1 == 'edit' and $param2 > 0)
    	{
    		if($_SERVER['REQUEST_METHOD'] == 'POST'){
    			$id = $this->input->post('id');
    			$update_product_order['sales_date'] 		= $this->input->post('sales_date');
    			$update_product_order['amount'] 			= $this->input->post('amount');
    			$update_product_order['sales_tax']   		= $this->input->post('sales_tax');
    			$update_product_order['insert_time']		= date('Y:m:d H:m:s');
    			
				$update_done = $this->db->where('id',$param2)->update('tbl_invoice',$update_product_order);

				if($update_done){
					$this->session->set_flashdata('message',"Product Order Updated Successfully!");
					redirect('admin/product_order/edit/'.$param2);
				}else{
					$this->session->set_flashdata('message',"Product Order Updated Failed!");
					redirect('admin/product_order/edit/'.$param2);
				}
    		}

    		$data['title'] 			= 'Manage Product Order';
	    	$data['activeMenu'] 	= 'product_order_edit';
	    	$data['page'] 			= 'backEnd/admin/product_order_edit';
	    	$data['product_order_edit']	= $this->AdminModel->product_order_edit($param2);

	    	$this->load->view('backEnd/master_page',$data);
    	}
    	elseif($param1 == 'delete' and $param2 > 0){
    		$product_order_delete = $this->AdminModel->product_order_delete($param2);

    		if($product_order_delete){
    			$this->session->set_flashdata('message',"Product Order Deleted Successfully!");
				redirect('admin/product_order/');
    		}
    		else{
    			$this->session->set_flashdata('message',"Product Order Deleted Failed!");
				redirect('admin/product_order/');
    		}
    	}
		elseif($param1 == 'payment_details' and $param2 > 0){

			$data['title'] 			= 'Manage Product Order';
	    	$data['activeMenu'] 	= 'product_order_add';
	    	$data['product_info']	= $this->AdminModel->product_order_info($param2);
	    	//print '<pre>'; print_r($data['product_info']);die;
	    	$data['payment_info']	= $this->AdminModel->payment_info($param2);
	    	$data['payment_method']	= $this->AdminModel->payment_method();
	    	$data['page'] 			= 'backEnd/admin/make_payment_add';

	    	$this->load->view('backEnd/master_page',$data);
    	}
    	elseif($param1 == 'approve_payment' and $param2 > 0){

    		$payment_id         		= $param2;
            $invoice_id         		= $param3;

            $update_data['approved_by'] = $this->session->userdata('userid');
            $update_data['approved']    = 1;

            $this->db->where('id', $payment_id)->update('tbl_payment', $update_data);

            $this->session->set_flashdata('message', $this->lang->line('update_msg'));
            redirect('admin/product_order/payment_details/' . $invoice_id, 'refresh');
    	}
    	elseif($param1 == 'cancel_payment' and $param2 > 0){

    		$payment_id         		= $param2;
            $invoice_id         		= $param3;

            $update_data['approved_by'] = 0;
            $update_data['approved']    = 0;

            $this->db->where('id', $payment_id)->update('tbl_payment', $update_data);

            $this->session->set_flashdata('message', $this->lang->line('update_msg'));
            redirect('admin/product_order/payment_details/' . $invoice_id, 'refresh');
    	}
    	elseif($param1 == 'save_amount' and $param2 > 0){
    		
            $tbl_payment['invoice_id'] 		= $param2;

            $tbl_payment['amount']          = $this->input->post('amount');
            $tbl_payment['method_id']       = $this->input->post('method_id');
            //$tbl_payment['client_id']          = $this->input->post('user_id');
            $tbl_payment['date_time']       = date('Y-m-d',strtotime($this->input->post('payment_date')));
            $tbl_payment['remarks']         = $this->input->post('payment_to');

            if ($tbl_payment['method_id'])
                $this->db->insert('tbl_payment', $tbl_payment);

            else
                redirect('admin/product/payment_details/' . $param2, 'refresh');

            $payment_id   = $this->db->insert_id();

            $payment_info = $this->db->where('id', $tbl_payment['method_id'])->get('tbl_payment_method')->row();

            if ($payment_info->name == 'BKASH') {

                $bkash_payment['payment_id']     = $payment_id;
                $bkash_payment['transaction_id'] = $this->input->post('transaction_id');
                $bkash_payment['sender']         = $this->input->post('sender');

                $this->db->insert('tbl_bkash_transaction', $bkash_payment);

            } else if ($payment_info->name == 'BANK') {

                $bank_payment['payment_id']     = $payment_id;
                $bank_payment['transaction_id'] = $this->input->post('transaction_id');
                $bank_payment['account_name']   = $this->input->post('account_name');
                $bank_payment['account_no']     = $this->input->post('account_no');
                $bank_payment['branch_name']    = $this->input->post('branch_name');
                $bank_payment['bank_name']      = $this->input->post('bank_name');

//                echo '<pre>';
//                print_r($bank_payment);
//                exit();
                $this->db->insert('tbl_bank_transaction', $bank_payment);
            }

            redirect('admin/product_order/payment_details/' . $tbl_payment['invoice_id'], 'refresh');
    	}
    	elseif($param1 == 'approve_order' and $param2 > 0){
    		$invoice_id		            = $param2;
            $update_data['approved_by'] = $this->session->userdata('userid');
            $update_data['aproved']    	= 1;
            $this->db->where('id', $invoice_id)->update('tbl_invoice', $update_data);
            $this->session->set_flashdata('message', $this->lang->line('update_msg'));
            redirect('admin/product_order/list', 'refresh');
    	}
    	elseif($param1 == 'cancel_order' and $param2 > 0){
    		$invoice_id		            = $param2;
            $update_data['approved_by'] = 0;
            $update_data['aproved']    	= 0;
            $this->db->where('id', $invoice_id)->update('tbl_invoice', $update_data);
            $this->session->set_flashdata('message', $this->lang->line('update_msg'));
            redirect('admin/product_order/list', 'refresh');
    	}
    	else{
    		$data['title'] 			= 'Manage Product Order';
	    	$data['activeMenu'] 	= 'product_order_list';
	    	$data['page'] 			= 'backEnd/admin/product_order_list';
	    	$data['product_order']	= $this->AdminModel->product_order_list();

	    	$this->load->view('backEnd/master_page',$data);
    	}
    }
    public function payment($param1 = '',$param2='',$param3='') 
    {
	    $method_id          = $this->input->post('method_id');
	    
	    //$tbl_sale_record_id = $this->input->post('tbl_sale_record_id');
	   
	    $method_info        = $this->db->where('id', $method_id)->get('tbl_payment_method')->row();

	    if ($param1 == 'check') {

	        $payment_status = $this->db->where('method_id', $method_id)->get('tbl_payment')->row();

	        if ($payment_status) {

	            $payment_id 		= $payment_status->id;	
	            $data['amount'] 	= $payment_status->amount;
	            $data['remarks'] 	= $payment_status->remarks;

	            if ($method_info->name == 'BKASH') {

	                $data['bkash_info'] = $this->db->where('payment_id', $payment_id)->get('tbl_bkash_transaction')->row();
	                $this->load->view('backEnd/admin/payment_bkash_edit', $data);

	            } else if ($method_info->name == 'BANK') {

	                $data['bank_info'] = $this->db->where('payment_id', $payment_id)->get('tbl_bank_transaction')->row();
	                $this->load->view('backEnd/admin/payment_bank_edit', $data);

	            } else {

	                $this->load->view('backEnd/admin/payment_cash_edit', $data);

	            }

	        } else {

	            if ($method_info->name == 'BKASH') {

	                $this->load->view('backEnd/admin/payment_bkash');

	            } else if ($method_info->name == 'BANK') {

	                $this->load->view('backEnd/admin/payment_bank');

	            } else {

	                $this->load->view('backEnd/admin/payment_cash');
	            }
	        }
	      }
    }//end payment

}
