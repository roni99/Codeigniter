<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php
	class AdminModel extends CI_Model{
		
	// $returnmessage can be num_rows, result_array, result
		public function isRowExist($tableName,$data, $returnmessage, $user_id = NULL){
		
				$this->db->where($data);
				if($user_id !== NULL) {
						$this->db->where('userId',$user_id);
				}
				if($returnmessage == 'num_rows'){
						return $this->db->get($tableName)->num_rows();
				}else if($returnmessage == 'result_array'){
						return $this->db->get($tableName)->result_array();
				}else{
						return $this->db->get($tableName)->result();
				}
		}
			// saveDataInTable table name , array, and return type is null or last inserted ID.
		public function saveDataInTable($tableName, $data, $returnInsertId = 'false'){
		
				$this->db->insert($tableName,$data);
				if($returnInsertId == 'true'){
						return $this->db->insert_id();
				}else{
						return -1;
				}
		}
			
		public function check_campaign_ambigus($start_date, $end_date){
					
				if(date_format(date_create($start_date),"Y-m-d") > date_format(date_create($end_date),"Y-m-d")){
						return -2;
					}
		
				$this -> db -> limit(1);
				$this -> db -> where('end_date >=', $start_date);
				$this -> db -> where('available_status', 1);
				$query = $this->db->get('create_campaign')->num_rows();
				if($query > 0){
						return -1;
				}
				return 1;
		}
		
		public function end_date_extends($end_date, $id){
		
				$this -> db -> limit(1);
				$this -> db -> where('start_date >=', $end_date);
				$this -> db -> where('id', $id);
				$this -> db -> where('available_status', 1);
				$query = $this->db->get('create_campaign')->num_rows();
				if($query > 0){
						return -1;
				}
				$this -> db -> limit(1);
				$this -> db -> where('end_date >=', $end_date);
				$this -> db -> where('id !=', $id);
				$this -> db -> where('available_status', 1);
				$query2 = $this->db->get('create_campaign')->num_rows();
				if($query2 > 0){
						return -1;
				}
				return 1;
		}
		public function fetch_data_pageination($limit, $start, $table, $search=NULL, $approveStatus=NULL, $user_id =NULL) {
				
				$this->db->limit($limit, $start);
	
			if($approveStatus!==NULL ){
						$this->db->where('approveStatus',$approveStatus);
				}
	
				if($user_id !== NULL ){
						$this->db->where('userId', $user_id);
				}
	
				if($search !== NULL){
						$this->db->like('title',$search);
						$this->db->or_like('body',$search);
						$this->db->or_like('date',$search);
				}
	
				$this->db->order_by('date','desc');
				$query = $this->db->get($table);
	
				if ($query->num_rows() > 0) {
						foreach ($query->result_array() as $row) {
								$data[] = $row;
						}
						return $data;
				}
				return false;
		}
		public function fetch_images($limit=18, $start=0, $table, $search=NULL,$where_data=NULL) {
				
				$this->db->limit($limit, $start);
	
				if($search !== NULL){
						$this->db->like('date',$search);
						$this->db->or_like('photoCaption',$search);
				}
				if($where_data !== NULL){
						$this->db->where($where_data);
				}
				$this->db->group_by('photo');
				$this->db->order_by('date','desc');
				$query = $this->db->get($table);
	
				if ($query->num_rows() > 0) {
						foreach ($query->result_array() as $row) {
								$data[] = $row;
						}
						return $data;
				}
				return false;
		}
		
		public function usersCategory($userId){
	
				$this->db->select('category.*');
				$this->db->join('category' , 'category_user.categoryId = category.id', 'left');
				$this->db->where('category_user.userId',$userId);
				return $this->db->get('category_user')->result_array();
		}
		
		
		public function get_user($user_id)
		{
			 $query = $this->db->select('user.*,tbl_upozilla.*')
							->where('user.id',$user_id)
							->from('user')
							->join('tbl_upozilla','user.address = tbl_upozilla.id', 'left')
							->get();
	
				return $query->row();
		}
		
		public function update_pro_info($update_data, $user_id)
		{
			 return $this->db->where('id',$user_id)->update('user',$update_data);
		}

		// Category table part //
		public function category_update($data, $id)
		{
			return $this->db->where('id',$id)->update('tbl_category',$data);
		}

		public function category_delete($id)
		{
			return $this->db->where('id',$id)->delete('tbl_category');
		}

		// delivery policy part 
		public function delivery_policy_update($update_data, $id)
		{
			return $this->db->where('id',$id)->update('tbl_delivary_policy',$update_data);
		}
		public function delivery_policy_delete($id)
		{
			return $this->db->where('id',$id)->delete('tbl_delivary_policy');
		}

		// term policy update part 
		public function term_policy_update($update_data,$id)
		{
			return $this->db->where('id',$id)->update('tbl_tearm_policy',$update_data);
		}
		public function term_policy_delete($id)
		{
			return $this->db->where('id',$id)->delete('tbl_tearm_policy');
		}

		// product part 
		public function product()
		{
			return $this->db->select('t1.*,t2.id as id2,t2.video_path')
							->from('tbl_product t1')
							->join('tbl_product_video t2','t1.id=t2.product_id','left')
							->get()
							->result_array();
		}
		public function product_delete($id)
		{
			$get_thumbphoto = $this->db->select('thumb_photo')
											->get_where('tbl_product',array('id'=>$id))
											->row()->thumb_photo;
						if (file_exists($get_thumbphoto)) {
							unlink($get_thumbphoto);
						}
			$get_productphoto = $this->db->select('photo')
											->get_where('tbl_product_photo',array('product_id'=>$id))
											->row()->photo;
						if (file_exists($get_productphoto)) {
							unlink($get_productphoto);
						}
			$this->db->where('id',$id)->delete('tbl_product');
			$this->db->where('product_id',$id)->delete('tbl_product_category');
			$this->db->where('product_id',$id)->delete('tbl_product_delivary_policy');
			$this->db->where('product_id',$id)->delete('tbl_product_video');
			$this->db->where('product_id',$id)->delete('tbl_product_photo');
			return true;
		}
		public function product_offer_list()
		{
			return $this->db->select('tbl_product_offer.*,tbl_product.name')
				     ->from('tbl_product_offer')
				     ->join('tbl_product','tbl_product.id=tbl_product_offer.product_id')
				     ->get('')
				     ->result();
		}
		public function product_offer_delete($id)
		{
			return $this->db->where('id',$id)->delete('tbl_product_offer');
		}

		public function product_order_list()
		{
			return $this->db->select('*')
						    ->from('tbl_invoice')
						    ->where('deleted',0)
						    ->get('')
						    ->result();
		}
		public function product_order_edit($id)
		{
			return $this->db->select('*')
						    ->from('tbl_invoice')
						    ->where('id',$id)
						    ->get('')
						    ->row();
		}
		public function product_order_delete($id)
		{
			return $this->db->where('id',$id)->set('deleted',1)->update('tbl_invoice');
		}
		public function product_order_info($id)
		{
			return $this->db->select('tbl_invoice.*,tbl_invoice_details.invoice_id,tbl_invoice_details.product_id,tbl_invoice_details.quantity,tbl_product.name,tbl_product.product_code,tbl_product.description,tbl_product.price')
						    ->from('tbl_invoice')
						    ->join('tbl_invoice_details','tbl_invoice.id=tbl_invoice_details.invoice_id')
						    ->join('tbl_product','tbl_invoice_details.product_id=tbl_product.id')
						    ->where('tbl_invoice.id',$id)
						    ->get('')
						    ->row();
		}
		public function payment_info($id)
		{
			return $this->db->select('*')
							->from('tbl_payment')
							->where('invoice_id',$id)
							->get()
							->result();
		}
		public function payment_method()
		{
			return $this->db->select('*')->from('tbl_payment_method')->get()->result();
		}

	}
	
?>

