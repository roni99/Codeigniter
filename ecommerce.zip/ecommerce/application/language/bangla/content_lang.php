<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['main_navigation'] = 'MAIN NAVIGATION';

//common part

$lang['sl']       = 'ক্র';
$lang['name']     = 'নাম';
$lang['title']    = 'শিরোনাম';
$lang['subtitle'] = 'সাবটাইটেল';
$lang['priority'] = 'অগ্রাধিকার';
$lang['cancel']   = 'বাতিল';
$lang['reset']    = 'রিসেট';
$lang['save']     = 'সেভ';
$lang['image']    = 'ছবি';
$lang['action']   = 'একশান';
$lang['delete']   = 'ডিলিট';
$lang['update']   = 'আপডেট';
$lang['submit']   = 'সাবমিট';

// dashboard part

$lang['dashboard']     = 'ড্যাশবোর্ড';

// user part

$lang['manage_user']            = 'ম্যানেজ ইউজার';
$lang['add_user']               = 'ইউজার যোগ';
$lang['user_list']              = 'ইউজার তালিকা';
$lang['first_name']             = 'নামের প্রথম অংশ';
$lang['last_name']              = 'নামের শেষাংশ';
$lang['user_name']              = 'ইউজারের নাম';
$lang['email']                  = 'ইমেইল'; 
$lang['phone']                  = 'ফোন';
$lang['password']               = 'পাসওয়ার্ড';
$lang['division']               = 'বিভাগ';
$lang['district']               = 'জেলা';
$lang['upozilla']               = 'উপজেলা'; 
$lang['select_a_division']      = 'বিভাগ নির্বাচন করুন';
$lang['select_division_first']  = 'জেলা নির্বাচন করুন';
$lang['select_district_first']  = 'উপজেলা নির্বাচন করুন';
$lang['road_house']             = 'রাস্তা/বাসা';
$lang['user_type']              = 'ইউজার টাইপ';
$lang['user']                   = 'ইউজার';
$lang['user_photo']             = 'ইউজারের ছবি';
$lang['user_photo_caption']     = 'ইউজার ছবি আপলোড করবে';
$lang['suspend']                = 'সাস্পেন্ড';

//profile part

$lang['profile']         = 'প্রোফাইল';
$lang['user_info']       = 'ইউজারের তথ্য';
$lang['password_change'] = 'পাসওয়ার্ড পরিবর্তন';
$lang['old_password']    = 'পুরাতন পাসওয়ার্ড';
$lang['new_password']    = 'নতুন পাসওয়ার্ড';
$lang['sing_out']        = 'সাইন আউট';
$lang['mail']            = 'মেইল';
$lang['web_mail']        = 'ওয়েব মেইল';
$lang['facebook']        = 'ফেসবুক';

// Category part 

$lang['manage_category']= 'ম্যানেজ ক্যাটাগরি';
$lang['category_add']	= 'ক্যাটাগরি যোগ';
$lang['category_list']  = 'ক্যাটাগরি তালিকা'; 
$lang['name_bn']		= 'নাম (বাংলা)';
$lang['name_en']		= 'নাম (ইংরেজি)';
$lang['url_make']		= 'ইউআরএল';
$lang['parent_id']		= ' প্যারেন্ট ক্যাটাগরি';
$lang['priority']		= 'প্রায়োরিটি';

// delivery policy part

$lang['manage_delivery_policy']		= 'ম্যানেজ ডেলিভারি পলিসি';
$lang['delivery_policy_add']		= 'ডেলিভারি পলিসি যোগ';
$lang['delivery_policy_list']		= 'ডেলিভারি পলিসি তালিকা';
$lang['delivery_policy_edit']		= 'ডেলিভারি পলিসি এডিট';
$lang['area']						= 'এরিয়া';
$lang['days']						= 'দিন';
$lang['cost']						= 'দাম';

// Term policy part

$lang['manage_term_policy']		= 'ম্যানেজ টার্ম পলিসি';
$lang['term_policy_add']		= 'টার্ম পলিসি যোগ';
$lang['term_policy_list']		= 'টার্ম পলিসি তালিকা';
$lang['term_policy_edit']		= 'টার্ম পলিসি এডিট';
$lang['title']					= 'টাইটেল';
$lang['body']					= 'বডি';


// Product part

$lang['manage_product']		= 'ম্যানেজ প্রোডাক্ট';
$lang['product_add'] 		= ' প্রোডাক্ট যোগ';
$lang['product_list']		= 'প্রোডাক্ট তালিকা';
$lang['product_edit']		= 'এডিট প্রোডাক্ট';
$lang['product_name']		= 'নাম';
$lang['product_code']		= 'কোড';
$lang['product_url']		= 'লিংক';
$lang['product_qty']		= 'সংখ্যা';
$lang['product_price']		= 'দাম';
$lang['product_color']		= 'রং';
$lang['product_size']		= 'সাইজ';
$lang['product_brand']		= 'ব্র্যান্ড';
$lang['product_category']	= 'ক্যাটাগরি';
$lang['product_video_link'] = 'লিংক';
$lang['product_desc']		= 'বর্ণনা';
$lang['product_thumbphoto']	= 'থাম্ব ছবি';
$lang['product_photo']		= 'প্রোডাক্ট ছবি';
$lang['upload_photo']		= 'আপলোড ছবি';
$lang['delivery_policy']	= 'ডেলিভারি পলিসি';

// Product Offer part

$lang['manage_product_offer']	= 'ম্যানেজ প্রোডাক্ট Offer';
$lang['product_offer_add'] 		= 'Add প্রোডাক্ট Offer যোগ';
$lang['product_offer_list']		= 'প্রোডাক্ট Offer তালিকা';
$lang['product_offer_edit']		= 'এডিট প্রোডাক্ট Offer';
$lang['product_id']				= 'প্রোডাক্ট নাম';
$lang['start_date']				= 'তারিখ শুরু';
$lang['end_date']				= 'শেষ তারিখ';
$lang['discount']				= 'ছাড়';
$lang['product_photo']			= 'প্রোডাক্ট ছবি';

