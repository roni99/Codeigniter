<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['main_navigation'] = 'MAIN NAVIGATION';

//common part

$lang['sl']       = 'SL';
$lang['name']     = 'Name';
$lang['title']    = 'Title';
$lang['subtitle'] = 'Subtitle';
$lang['priority'] = 'Priority';
$lang['cancel']   = 'Cancel';
$lang['reset']    = 'Reset';
$lang['save']     = 'Save';
$lang['image']    = 'Image';
$lang['action']   = 'Action';
$lang['delete']   = 'Delete';
$lang['update']   = 'Update';
$lang['submit']   = 'Submit';

// dashboard part

$lang['dashboard']     = 'Dashboard';



// user part

$lang['manage_user']           = 'Manage User';
$lang['add_user']              = 'Add User';
$lang['user_list']             = 'User List';
$lang['update_user']           = 'Update User';
$lang['first_name']            = 'First Name';
$lang['last_name']             = 'Last Name';
$lang['user_name']             = 'User Name';
$lang['email']                 = 'Email';
$lang['phone']                 = 'Phone';
$lang['password']              = 'Password';
$lang['division']              = 'Division';
$lang['district']              = 'District';
$lang['upozilla']              = 'Upozilla';
$lang['select_a_division']     = 'Select A Division';
$lang['select_division_first'] = 'Select Division First';
$lang['select_district_first'] = 'Select District First';
$lang['road_house']            = 'Road/House';
$lang['user_type']             = 'User Type';
$lang['user']                  = 'User';
$lang['user_photo']            = 'User Photo';
$lang['user_photo_caption']    = 'Photo will be uploaded by User';
$lang['suspend']               = 'Suspend';

//profile part

$lang['profile']         = 'Profile';
$lang['user_info']       = 'User Info';
$lang['password_change'] = 'Password Change';
$lang['old_password']    = 'Old Password';
$lang['new_password']    = 'New Password';
$lang['sign_out']        = 'Sign Out';
$lang['mail']            = 'Mail';
$lang['web_mail']        = 'Webmail';
$lang['facebook']        = 'Facebook';

// Category part 

$lang['manage_category']	= 'Manage Category';
$lang['category_add']		= 'Add Category';
$lang['category_list']		= 'Category List'; 
$lang['name_bn']			= 'Name (Bangla)';
$lang['name_en']			= 'Name (English)';
$lang['url_make']			= 'URL Make';
$lang['parent_id']			= 'Parent Category';
$lang['priority']			= 'Priority';

// delivery policy part

$lang['manage_delivery_policy']		= 'Manage Delivery Policy';
$lang['delivery_policy_add']		= 'Delivery Policy Add';
$lang['delivery_policy']			= 'Delivery Policy';
$lang['delivery_policy_list']		= 'Delivery Policy List';
$lang['delivery_policy_edit']		= 'Delivery Policy Edit';
$lang['area']						= 'Area';
$lang['days']						= 'Days';
$lang['cost']						= 'Cost';

// Term policy part

$lang['manage_term_policy']		= 'Manage Term Policy';
$lang['term_policy_add']		= 'Term Policy Add';
$lang['term_policy_list']		= 'Term Policy List';
$lang['term_policy_edit']		= 'Term Policy Edit';
$lang['title']					= 'Title';
$lang['body']					= 'Body';

// Product part

$lang['manage_product']		= 'Manage Product';
$lang['product_add'] 		= 'Add Product';
$lang['product_list']		= 'Product List';
$lang['product_edit']		= 'Edit Product';
$lang['product_name']		= 'Name';
$lang['product_code']		= 'Code';
$lang['product_url']		= 'Url';
$lang['product_qty']		= 'Qty';
$lang['product_price']		= 'Price';
$lang['product_color']		= 'Color';
$lang['product_size']		= 'Size';
$lang['product_brand']		= 'Brand';
$lang['product_category']	= 'Category';
$lang['product_video_link'] = 'Video Link';
$lang['product_desc']		= 'Description';
$lang['product_thumbphoto']	= 'Thumb Photo';
$lang['product_photo']		= 'Product Photo';
$lang['upload_photo']		= 'Upload Photo';
$lang['delivery_policy']	= 'Delivery Policy';

// Product Offer part

$lang['manage_product_offer']	= 'Manage Product Offer';
$lang['product_offer_add'] 		= 'Add Product Offer';
$lang['product_offer_list']		= 'Product Offer List';
$lang['product_offer_edit']		= 'Edit Product Offer';
$lang['product_id']				= 'Product Name';
$lang['start_date']				= 'Start Date';
$lang['end_date']				= 'End Date';
$lang['discount']				= 'Discount';
$lang['product_photo']			= 'Product Photo';
$lang['upload_photo']			= 'Upload Photo';

// Product Order list part

$lang['manage_product_order']	= 'Manage Product Order';
$lang['product_order_add'] 		= 'Add Product Order';
$lang['product_order_list']		= 'Product Order List';
$lang['product_order_edit']		= 'Edit Product Order';
$lang['sales_date']				= 'Sales Date';
$lang['amount']					= 'Amount';
$lang['sales_tax']				= 'Sales Tax';
$lang['user']					= 'User';
$lang['details']				= 'Details';
$lang['approved']				= 'Approved';
$lang['cancel']					= 'Cancel';
$lang['payment']				= 'Make Payment';
$lang['edit']					= 'Edit';

// Make Payment part

$lang['add_amount']				= 'Add Amount';
$lang['payment_date']			= 'Payment Date';
$lang['payment']				= 'Payment';
$lang['payment_details']		= 'Payment Details';
$lang['payment_completed']		= ' Payment Completed';
$lang['payment_not_completed']  = ' Payment Not Completed';	
$lang['transaction_id']			= 'Transaction Id';
$lang['sender']					= 'Sender';
$lang['date']					= 'Date';
$lang['method']					= 'Method';
$lang['amount']					= 'Amount';
$lang['payment_to']				= 'Payment to';	
$lang['approved_by']			= 'Approved by';
$lang['update_msg']				= 'Update Successfully';

$lang['account_name']			= 'Account Name';
$lang['account_no']				= 'Account No';
$lang['branch_name']			= 'Brance Name';
$lang['bank_name']				= 'Bank Name';


