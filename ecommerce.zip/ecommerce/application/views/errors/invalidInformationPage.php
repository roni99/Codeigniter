<section class="content">
    <div class="row">
        <div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
        	
        </div>
        <div class="col-lg-6 col-md-8 col-sm-10 col-xs-10">
        	
        	<center>
        		<i class="fa fa-frown-o" aria-hidden="true" style="color: red; font-size: 250px;"></i>
        	</center>

        </div>
        <div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
        	
        </div>
    </div>
    <div class="row">
    	<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
        	
        </div>
        <div class="col-lg-6 col-md-8 col-sm-10 col-xs-10">

        	<center >
             <?php echo "<h2>". $noteMessage . "</h2>" ; ?>   
            </center>

        </div>
        <div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
        	
        </div>
    </div>
</section>