<!-- Main content -->
<?php
    //var_dump($payment_info);die;
    $sum=0;
    foreach ($payment_info as $value) {
        if($value->approved !='0') $sum += $value->amount;
    }
?>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div <?php if($sum >=  $product_info->amount) echo "class='box box-success' style='background-color: rgba(113, 206, 163, 0.61);'"; else echo "class='box box-warning box-solid'"; ?> >
                <div class="box-header">
                    <h3 class="box-title"><?php echo $this->lang->line("payment_details"); ?></h3> <small style="color: red;"><b><?php if($sum >=  $product_info->amount) echo $this->lang->line("payment_completed"); else echo $this->lang->line("payment_not_completed"); ?></b></small>
                </div>
                <div class="box-body ">
                    <div class="col-sm-4">
                        <ul>
                            <li><?php echo 'Product Order ID : #00' . $product_info->id; ?></li>
                            <li><?php echo 'Order Date : ' . $product_info->sales_date; ?></li>
                            <li><?php echo 'Username : ' . $this->db->where('id',$product_info->user_id)->get('user')->row()->username; ?></li>                 
                            
                        </ul>
                    </div>
                    <div class="col-sm-4">
                        <ul>
                            <li><?php echo 'Total Amount : ' . number_format((float)$product_info->amount, 2, '.', ''); ?> .TK</li>                        
                        </ul>
                    </div>
                    <div class="col-sm-4">
                        <ul>
                            <li><?php echo 'Sales Tax : ' . number_format((float)$product_info->sales_tax, 2, '.', ''); ?></li>
                            <li><?php echo 'Product Quantity : ' .$product_info->quantity; ?></li>
                            <li><?php echo 'Approved_by : ' . $product_info->approved_by > 0 ?  $this->db->where('id',$product_info->user_id)->get('user')->row()->username : 'Approved By : '; ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary box-solid">
                <div class="box-header">
                    <h3 class="box-title"><?php echo $this->lang->line("add_amount"); ?></h3>
                </div>
                <div class="box-body">
                    <form action="<?php echo base_url("admin/product_order/save_amount/" . $product_info->id); ?>" method="post" enctype="multipart/form-data" class="form-horizontal" autocomplete="on">

                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment_date"); ?></label>
                            <div class="col-sm-8">
                                <input type="text" name="payment_date" class="form-control" id="date" autocomplete="off" placeholder="<?php echo $this->lang->line('payment_date'); ?>" required="">
                                <input type="hidden" name="user_id" class="form-control" value="<?php echo $product_info->user_id; ?>" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment"); ?></label>
                            <div class="col-sm-8">
                                <select class="select2 form-control" name="method_id" id="method_id" required="">
                                    <?php
                                    foreach ($payment_method as $p_info) {
                                        ?>
                                        <option value="<?php echo $p_info->id; ?>"><?php echo $p_info->name; ?></option>
                                    <?php
                                        }
                                    ?>
                                    <option value="" selected>No payment</option>
                                </select>
                            </div>
                        </div>
                        <span id="payment_fields"></span>

                    <!-- /.box-body -->
                        <div class="col-md-12">
                            <center>
                                <button type="reset" class="btn btn-sm btn-danger"><?php echo $this->lang->line("reset"); ?></button>
                                <button type="submit" class="btn btn-sm btn-primary"><?php echo $this->lang->line("save"); ?></button>
                            </center>
                        </div>
                    <!-- /.box-footer -->
                    </form>
                </div>

                    <center> <h3 style="font-weight: bold;color: #656363;"> <?php echo $this->lang->line("payment_details"); ?> </h3> </center>

                <div id="print_area" class="box-body">
                    <table id="example1" class=" demo table table-bordered table-striped table_th_primary">
                        <thead>
                            <tr>
                                <th style="width: 5%;"><?php echo $this->lang->line("sl"); ?></th>
                                <th style="width: 10%;"><?php echo $this->lang->line("date"); ?></th>
                                <th style="width: 10%;"><?php echo $this->lang->line("method"); ?></th>
                                <th style="width: 15%;"><?php echo $this->lang->line("amount"); ?></th> 
                                <th style="width: 10%;"><?php echo $this->lang->line("approved"); ?></th>
                                <th style="width: 25%;"><?php echo $this->lang->line("approved_by"); ?></th>
                                <th style="width: 25%;"><?php echo $this->lang->line("payment_to"); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($payment_info as $key => $value) {
                                ?>
                                <tr>
                                    <td> <?php echo ++$key; ?> </td>
                                    <td> <?php echo date('d M Y',strtotime($value->date_time)); ?> </td>
                                    <td><?php echo $this->db->where('id', $value->method_id)->get('tbl_payment_method')->row()->name; ?></td>

                                    <td style="text-align: right"><?php echo number_format((float)$value->amount, 2, '.', ''); ?>
                                    
                                    <td>
                                        <?php if($value->approved=='0'){  ?>

                                            <a href="<?php echo base_url('admin/product_order/approve_payment/') . $value->id.'/'.$product_info->id; ?>"><button type="button" class="btn btn-danger btn-sm pull-right">
                                                <span class="glyphicon glyphicon-thumbs-down"></span> 
                                                </button></a>

                                        <?php } else{ ?>

                                            <a href="<?php echo base_url('admin/product_order/cancel_payment/') . $value->id.'/'.$product_info->id; ?>"><button type="button" class="btn btn-sm pull-right btn-success">
                                                <span class="glyphicon glyphicon-thumbs-up"> </span> 
                                                </button></a>

                                        <?php } ?>

                                    </td>
                                    <td><?php if($value->approved > 0) {echo' '.$this->db->where('id',$value->approved)->get('user')->row()->firstname;} ?></td>
                                    </td>

                                     <td><?php echo $value->remarks; ?></td>

                                </tr>
                                <?php 
                            }
                            ?>                                
                        </tbody>
                        <tr>                            
                            <td colspan="3" style="text-align: right;">Total Paid </td>
                            <td style="text-align: right;"> <b> <?php echo number_format((float)$sum, 2, '.', ''); ?> </b></td>
                            <td colspan="3"></td>
                        </tr>
                    </table>
                    
                </div>

            </div>

        </div>

    </div>

</section>
<!-- /.content -->
<script type="text/javascript">
    $(function () {
        $("#example1").DataTable();
    });
</script>
<script type="text/javascript" >
    $(document).ready(function () {
        $("#method_id").change(function () {
            var method_id = ($(this).val());
            if (method_id) {
                $.post("<?php echo base_url() . "admin/payment/check"; ?>",
                        {method_id: method_id},
                        function (data) {
                            $("#payment_fields").html(data);
//                   alert(data);
                        });
            } else if (method_id === '') {
                $("#payment_fields").html('');
//             alert('Helllll');
            }
        });

    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
    });
</script>

<script>
    
    $(function () {

        $('#date').datepicker({

            autoclose: true,

            changeYear:true,

            changeMonth:true,

            dateFormat: "dd-mm-yy",

            yearRange: "-10:+10"

        });

    });
</script>
