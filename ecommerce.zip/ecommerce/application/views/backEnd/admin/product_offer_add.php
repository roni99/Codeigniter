

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-danger box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('product_offer_add'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/product_offer/list" type="submit" class="btn bg-orange btn-sm" style="color: white;"> <i class="fa fa-list"></i> <?php echo $this->lang->line('product_offer_list'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <form action="<?php echo base_url("admin/product_offer/add");?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                            <br><br>
                            <div class="col-md-12">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('start_date') ?></label>
                                            <div class="input-group date">
                                              <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                              </div>
                                              <input type="text" name="start_date" class="form-control pull-right" id="datepicker_start" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('end_date'); ?></label>
                                            <div class="input-group date">
                                              <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                              </div>
                                              <input type="text" name="end_date" class="form-control pull-right" id="datepicker_end" required="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('discount'); ?></label>
                                            <input name="discount" placeholder="<?php echo $this->lang->line('discount'); ?>" class="form-control inner_shadow_primary" type="text" id="discount" maxlength="2" required="">
                                        </div>
                                    </div>
                                </div> 

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('product_id') ?></label>
                                            <select class="form-control select2" name="product[]" multiple="" required="">
                                                <option value="">Select Product</option>
                                                <?php
                                                foreach($all_product as $product_list){
                                                ?>
                                                <option value="<?php print $product_list->id;?>"><?php print $product_list->name;?></option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <center>
                                    <button type="reset" class="btn btn-danger"><?php echo $this->lang->line('reset') ?></button>
                                    <button type="submit" id="submitbutton" class="btn bg-aqua"><?php echo $this->lang->line('save') ?></button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>

<script type="text/javascript">
    var dateToday = new Date(); 
     //Date picker
    $('#datepicker_start').datepicker({
      autoclose: true
    })
    $('#datepicker_start').datepicker("setDate", new Date());

     //Date picker
    $('#datepicker_end').datepicker({
      autoclose: true
    })
    

</script>

<script>
    $(function() { 
        
        $('#datepicker_end').change(function(){

            var start_year = $('#datepicker_start').val();
            var end_year   = $('#datepicker_end').val();

            if (start_year > end_year) {
                $('#submitbutton').hide(); 
                
            }else{
               $('#submitbutton').show(); 
            }
        });

    });
</script>

<script type="text/javascript">
    $(document).ready(function(){
    $('[id^=discount]').keypress(validateNumber);
});
function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        return false;
    } else {
        return true;
    }
}; 
</script>


