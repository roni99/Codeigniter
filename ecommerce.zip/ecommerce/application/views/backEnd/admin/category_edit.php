

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-danger box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('category_add'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/category/list" type="submit" class="btn bg-orange btn-sm" style="color: white;"> <i class="fa fa-plus"></i> <?php echo $this->lang->line('category_list'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <form action="<?php echo base_url("admin/category/edit/".$edit_info->id);?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                            <br><br>
                            <div class="col-md-12">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('name_bn'); ?></label>
                                            <input name="name_bn" placeholder="<?php echo $this->lang->line('name_bn'); ?>" value="<?php print $edit_info->name_bn;?>" class="form-control" required="" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('name_en') ?></label>
                                            <input name="name_en" placeholder="<?php echo $this->lang->line('name_en'); ?>" value="<?php print $edit_info->name_en;?>" class="form-control" required="" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('url_make'); ?></label>
                                            <input name="url_make" placeholder="<?php echo $this->lang->line('url_make'); ?>" value="<?php print $edit_info->url_make;?>" class="form-control" required="" type="text">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('parent_id'); ?></label>
                                            <select name="parent_id" class="form-control select2">
                                                <option value="">--Select One--</option>
                                                <?php
                                                //var_dump($category);die();
                                                foreach ($category as $key => $cat) {
                                                ?>
                                                 <option value="<?php print $cat['id'];?>"><?php print $cat['name_bn'];?></option>
                                                <?php }?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('priority'); ?></label>
                                            <input name="priority" placeholder="<?php echo $this->lang->line('priority'); ?>" value="<?php print $edit_info->priority;?>" class="form-control" type="number">
                                        </div>
                                    </div>
                                </div>
                               
                                
                            </div>
                            
                            <div class="col-md-12">
                                <center>
                                    <button type="reset" class="btn bg-aqua"><?php echo $this->lang->line('reset') ?></button>
                                    <button type="submit" class="btn btn-danger"><?php echo $this->lang->line('update') ?></button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>


