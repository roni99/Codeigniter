
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-danger box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('category_add'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/category/add" type="submit" class="btn bg-orange btn-sm" style="color: white;"> <i class="fa fa-plus"></i> <?php echo $this->lang->line('category_add'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <table id="userListTable" class="table table-hover table_th_maroon">
                                <thead>
                                    <tr>
                                        <th style="width: 2%;"><?php echo $this->lang->line('sl'); ?></th>
                                        <th style="width: 20%;"><?php echo $this->lang->line('name_bn'); ?></th>
                                        <th style="width: 20%;"><?php echo $this->lang->line('name_en'); ?></th>
                                        <th style="width: 10%;"><?php echo $this->lang->line('url_make'); ?></th>
                                        <th style="width: 5%;"><?php echo $this->lang->line('parent_id'); ?></th>
                                        <th style="width: 5%;"><?php echo $this->lang->line('priority'); ?></th>
                                        <th style="width: 5%;"><?php echo $this->lang->line('action'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        foreach ($category as $key => $value) {
                                            ?>
                                    <tr>
                                        <td> <?php echo ++$key ; ?> </td>
                                        <td> <?php echo $value->name_bn; ?> </td>
                                        <td> <?php echo $value->name_en; ?> </td>
                                        <td> <?php echo $value->url_make; ?> </td>
                                        <td> <?php echo $value->parent_id; ?> </td>
                                        <td> <?php echo $value->priority; ?> </td>
                                        <td> 
                                            <a href="<?php echo base_url('admin/category/edit/'.$value->id); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                            <a href="<?php echo base_url('admin/category/delete/'.$value->id); ?>" class="btn btn-sm btn-danger" onclick = 'return confirm("Are You Sure?")'><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.col -->
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>
<script>
    // profile picture change
    function readpicture(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
    
          reader.onload = function (e) {
            $('#teammember_picture_change')
            .attr('src', e.target.result)
            .width(100)
            .height(100);
        };
    
        reader.readAsDataURL(input.files[0]);
    }
 }
    
</script>

<script type="text/javascript">
    $(function () {
      $("#userListTable").DataTable();
    });
    
</script>


