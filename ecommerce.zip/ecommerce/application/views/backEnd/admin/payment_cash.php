<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("amount"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="amount" class="form-control" placeholder="" required="">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment_to"); ?></label>    
    <div class="col-sm-8">        
    	<input value="" type="text" name="payment_to" class="form-control" placeholder="" required="">    
    </div>
</div>



