<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"><h3 class="box-title"> <?php echo $this->lang->line('product_order_list'); ?> </h3></h3>
                    <div class="box-tools pull-right">
                        <a onclick="print_page();" class="btn btn-success btn-sm"  title="Print"  > <i class="fa fa-print"> </i> <?php echo $this->lang->line('print'); ?> </a>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body" id="print_area">
                    <table id="userListTable" class="table table-bordered table-striped table_th_primary">
                        <thead>
                            <tr>
                                <th><?php echo $this->lang->line("sl"); ?></th>
                                <th><?php echo $this->lang->line("sales_date"); ?></th>
                                <th class="hidden-xs"><?php echo $this->lang->line("amount"); ?></th>
                                <th class="hidden-xs"><?php echo $this->lang->line("sales_tax"); ?></th>
                                <th class="hidden-xs"><?php echo $this->lang->line("user"); ?></th>
                                <th><?php echo $this->lang->line("action"); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach ($product_order as $key => $value) {
                            ?>
                                <tr>
                                    <td> <?php echo ++$key ; ?> </td>
                                    <td> <?php echo date('d M Y',strtotime($value->sales_date)) ; ?> </td>
                                    <!-- <td>
                                        <?php
                                            $product_id = $value->product_id;
                                            $product_name_info = $this->db->where('id', $product_id)->get('tbl_product')->row();
                                            echo $product_name_info->name;
                                            ?>
                                    </td> -->
                                    <td class="hidden-xs"><?php echo $value->amount; ?></td>
                                    <td class="hidden-xs"><?php echo $value->sales_tax; ?></td>
                                    <td class="hidden-xs"><?php echo $this->db->where('id',$value->user_id)->get('user')->row()->username; ?></td>
                                    <td>
                                        <div class="btn-group">
                                        <?php 
                                            $payment_info = $this->db->where('invoice_id', $value->id)->get('tbl_payment')->result();
                                                $sum=0;
                                                foreach ($payment_info as $val) {
                                                if($val->approved !='0') $sum+= $val->amount;
                                                }
                                        ?>
                                            <button type="button" class="btn btn-<?php echo $value->aproved == 1 ? ($sum >=$value->amount ? 'success':'warning'): 'danger'; ?>" data-toggle="modal" data-target="<?php echo "#" . $value->id; ?>"><?php echo $this->lang->line("details"); ?></button>

                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="<?php echo base_url('admin/product_order/edit/') . $value->id; ?>"><?php echo $this->lang->line("edit"); ?></a></li>
                                                <li class="divider"></li>

                                                <li><a href="<?php echo base_url('admin/product_order/delete/') . $value->id; ?>" onclick="return confirm('Are you sure to delete this?');"><?php echo $this->lang->line("delete"); ?></a></li>
                                                <li class="divider"></li>
                                                <li><a href="<?php echo base_url('admin/product_order/payment_details/') .$value->id; ?>"><?php echo $this->lang->line("payment"); ?></a></li>
                                                 <li class="divider"></li>
                                                 <?php 
                                                 $approval_status=$this->db->where('id',$value->id)->get('tbl_invoice')->row()->aproved;
                                                 if($approval_status==0) {?>
                                                 <li><a href="<?php echo base_url('admin/product_order/approve_order/') . $value->id; ?>" ><?php echo $this->lang->line("approved"); ?></a></li>
                                                 <?php } else { ?>
                                                <li><a href="<?php echo base_url('admin/product_order/cancel_order/') . $value->id; ?>" ><?php echo $this->lang->line("cancel"); ?></a></li>
                                                 <?php } ?>
                                            </ul>
                                        </div>
                                        <!-- Modal -->

                                        <div class="modal fade" id="<?php echo $value->id; ?>" role="dialog">
                                            <div class="modal-dialog">

                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        <h4 class="modal-title"></h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <table class="table table-bordered">
                                                            <tr>
                                                                <th>S.N</th>
                                                                <th>Product</th>
                                                                <th>Quantity</th>
                                                                <th>Price</th>
                                                            </tr>
                                                           <?php
                                                               $id=$value->id;
                                                              
                                                   $order_list=$this->db->select('*')
                                                                        ->from('tbl_invoice_details')
                                                                        ->join('tbl_product','tbl_invoice_details.product_id=tbl_product.id')
                                                                        ->where('tbl_invoice_details.invoice_id',$id)
                                                                        ->get()
                                                                        ->result();
                                                               foreach ($order_list as $key => $val) {
                                                            ?>
                                                           <tr>
                                                               <td><?php echo ++$key; ?></td>
                                                               <td><?php echo $val->name; ?></td>
                                                               <td><?php echo $val->quantity; ?></td>
                                                               <td><?php echo $val->price; ?></td>
                                                           </tr>
                                                           <?php }?>
                                                        </table>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </td>
                                </tr>
                                <?php
                                    }
                                    ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
</section>
<script type="text/javascript">
    $(function () {
      $("#userListTable").DataTable();
    });
    
</script>

<script type="text/javascript">

    function print_page() {

        var printContents = document.getElementById('print_area').innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;

    }

</script>



