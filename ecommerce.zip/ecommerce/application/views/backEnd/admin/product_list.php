

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('product_add'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/product/add" type="submit" class="btn bg-primary btn-sm" style="color: white;"> <i class="fa fa-plus"></i> <?php echo $this->lang->line('product_add'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <table id="userListTable" class="table table-bordered table-striped table_th_primary">
                                <thead>
                                    <tr>
                                        <th style="width: 2%;"><?php echo $this->lang->line('sl'); ?></th>
                                        <th style="width: 15%;"><?php echo $this->lang->line('product_name'); ?></th>
                                        <th style="width: 8%;"><?php echo $this->lang->line('product_code'); ?></th>
                                        <th style="width: 10%;"><?php echo $this->lang->line('product_url'); ?></th>
                                        <th style="width: 4%;"><?php echo $this->lang->line('product_qty'); ?></th>
                                        <th style="width: 4%;"><?php echo $this->lang->line('product_price'); ?></th>
                                        <th style="width: 10%;"><?php echo $this->lang->line('product_color'); ?></th>
                                        <th style="width: 15%;"><?php echo $this->lang->line('product_size'); ?></th>
                                        <th style="width: 7%;"><?php echo $this->lang->line('product_brand'); ?></th>                             
                                        <th style="width: 5%;"><?php echo $this->lang->line('product_thumbphoto'); ?></th>                       
                                        <th style="width: 10%;"><?php echo $this->lang->line('action'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        foreach ($products as $key => $value) {
                                    ?>
                                    <tr>
                                        <td><?php echo ++$key ; ?> </td>
                                        <td><?php echo $value['name'];?></td>
                                        <td><?php echo $value['product_code'];?></td>
                                        <td><?php echo $value['url_generate'];?></td>
                                       
                                        <td><?php echo $value['quantity'];?></td>
                                        <td><?php echo $value['price'];?></td>
                                        <td><?php echo $value['colors'];?></td>
                                        <td><?php echo $value['size'];?></td>
                                        <td><?php echo $value['brand'];?></td>
                                       <!--  <td><?php //echo $value['video_path']; ?></td> -->
                                       
                                        <td>
                                            <img src="<?php echo base_url().$value['thumb_photo'];?>" height="40">
                                        </td>
                                        <td> 
                                            <a href="<?php echo base_url('admin/product/edit/'.$value['id']); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                            <a href="<?php echo base_url('admin/product/delete/'.$value['id']); ?>" class="btn btn-sm btn-danger" onclick = 'return confirm("Are You Sure?")'><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.col -->
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>
<script>
    // profile picture change
    function readpicture(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
    
          reader.onload = function (e) {
            $('#teammember_picture_change')
            .attr('src', e.target.result)
            .width(100)
            .height(100);
        };
    
        reader.readAsDataURL(input.files[0]);
    }
 }
    
</script>

<script type="text/javascript">
    $(function () {
      $("#userListTable").DataTable();
    });
    
</script>


