<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('manage_product'); ?> </h3>
                    <div class="box-tools pull-right">
                         <a href="<?php echo base_url() ?>admin/product/list" type="submit" class="btn bg-primary btn-sm" style="color: white;"> <i class="fa fa-list"></i> <?php echo $this->lang->line('product_list'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                <div class="row">
                    <form action="<?php echo base_url("admin/product/add");?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                        <br><br>
                        <div class="col-md-9">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_name'); ?> </label>
                                        <input name="product_name" placeholder="<?php echo $this->lang->line('product_name'); ?> " class="form-control inner_shadow_green" required="" type="text">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_url'); ?> </label>
                                        <input name="product_url" placeholder="<?php echo $this->lang->line('product_url'); ?> " class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_qty'); ?> </label>
                                        <input name="product_qty" id="product_qty" placeholder="<?php echo $this->lang->line('product_qty'); ?> " class="form-control inner_shadow_green" maxlength="5" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_code'); ?> </label>
                                        <input name="product_code" placeholder="<?php echo $this->lang->line('product_code'); ?> " class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_price'); ?> </label>
                                        <input name="product_price" placeholder="<?php echo $this->lang->line('product_price'); ?>" id="product_price" maxlength="5" class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>   
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_color'); ?> </label>
                                        <select name="product_color" class="form-control select2" data-placeholder="Select Color">
                                            <option value="">Select One</option>
                                            <option value="red">Red</option>
                                            <option value="green">Green</option>
                                            <option value="orange">Orange</option>
                                            <option value="black">Black</option>
                                            <option value="white">White</option>
                                        </select>
                                    </div>
                                </div>
                            </div>  
                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php //echo $this->lang->line('product_size'); ?> </label>
                                       <select name="product_size[]" class="form-control select2" multiple="" data-placeholder="Select Size">
                                            <option>Select Size</option>
                                            <option value="small">Small</option>
                                            <option value="medium">Medium</option>
                                            <option value="large">Large</option>
                                            <option value="extra large">Extra Large</option>
                                        </select>                                             
                                    </div>
                                </div>
                            </div> --> 

                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_brand'); ?> </label>
                                       <input name="product_brand" placeholder="<?php echo $this->lang->line('product_brand'); ?>" id="" class="form-control inner_shadow_green" required="" type="text">                                              
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_video_link'); ?> </label>
                                       <input name="product_video_link" placeholder="<?php echo $this->lang->line('product_video_link'); ?>" id=""  class="form-control inner_shadow_green" required="" type="text">                                              
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_size'); ?> </label>
                                       <select name="product_size[]" class="form-control select2" multiple="" data-placeholder="Select Size">
                                            <option>Select Size</option>
                                            <option value="small">Small</option>
                                            <option value="medium">Medium</option>
                                            <option value="large">Large</option>
                                            <option value="extra large">Extra Large</option>
                                        </select>                                             
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('delivery_policy'); ?> </label>
                                        <select name="delivery_policy[]" class="form-control select2" multiple="" data-placeholder="Delivery Policy">
                                            <option value="">Select Size</option>
                                           <?php
                                            $delivery_policy = $this->db->get('tbl_delivary_policy')->result();
                                            foreach ($delivery_policy as $key => $value): ?>
                                               <option value="<?php echo $value->id;?>"><?php echo $value->area; ?></option>
                                           <?php endforeach ?>
                                        </select>                                           
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_desc'); ?> </label>
                                        <textarea name="product_desc" class="form-control inner_shadow_green" required=""></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                              <div class="form-group">
                                <div class="col-sm-12">
                                <label><?php echo $this->lang->line('product_category');?></label><br>
                                 <?php
                                    $category = $this->db->get('tbl_category')->result();
                                    foreach ($category as $key => $value): ?>
                                <label>
                                  <input type="checkbox" name="category[]" value="<?php echo $value->id;?>" class="flat-red"> <?php echo $value->name_en; ?> &nbsp;&nbsp;&nbsp;
                                </label>
                                 <?php endforeach ?>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <!-- Product Thumb Image -->
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <center>
                                        <label> <?php echo $this->lang->line('product_thumbphoto'); ?> </label> 
                                        <img id="thumb_photo" class="img-responsive" src="//placehold.it/400x400" alt="profile picture" style="max-width: 120px;">
                                        <br>
                                        <input type="file" name="product_thumbphoto" onchange="readpicture(this);" required="">
                                    </center>
                                </div>
                                <!-- /.box-body -->
                            </div>
                            <br>
                            <!-- Product Image -->  
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <center>
                                        <label> <?php echo $this->lang->line('product_photo'); ?> </label> 
                                        <img id="" class="img-responsive" src="//placehold.it/400x400" alt="profile picture" style="max-width: 120px;">
                                        <br>
                                        <input type="file" name="product_photo[]" multiple required="">
                                    </center>
                                </div>
                                <!-- /.box-body -->
                            </div>
                        </div>
                        <div class="col-md-12">
                            <center>
                                <button type="reset" class="btn btn-danger"><?php echo $this->lang->line('reset'); ?></button>
                                <button type="submit" class="btn bg-aqua"><?php echo $this->lang->line('save'); ?></button>
                            </center>
                        </div>
                    </form>
                </div>
             </div>
        </div>
        <!-- /.box -->
    </div>
    <!--/.col (right) -->
</div>
</section>

<script>
// profile picture change
function readpicture(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('#thumb_photo')
        .attr('src', e.target.result)
        .width(100)
        .height(100);
    };

    reader.readAsDataURL(input.files[0]);
}
}
</script>

<script type="text/javascript">
$(document).ready(function(){
    $('[id^=product_price]').keypress(validateNumber);
     $('[id^=product_qty]').keypress(validateNumber);
});

function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        return false;
    } else {
        return true;
    }
};  
  
</script>
<script>
  $(function () {  
    CKEDITOR.replace('product_desc')
    //$('.textarea').wysihtml5()
  })

   //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })
</script>