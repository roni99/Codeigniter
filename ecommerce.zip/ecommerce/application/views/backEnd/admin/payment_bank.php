<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("account_name"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="account_name" class="form-control" placeholder="" required="">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("account_no"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="account_no" class="form-control" placeholder="" required="">
    </div>
</div>

<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("branch_name"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="branch_name" class="form-control" placeholder="" required="">
    </div>
</div>

<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("bank_name"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="bank_name" class="form-control" placeholder="" required="">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("transaction_id"); ?></label>
    <div class="col-sm-8">
        <input value="" type="text" name="transaction_id" class="form-control" placeholder="" required="">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("amount"); ?></label>
    <div class="col-sm-8">
        <input value="" type="number" step="0.01" name="amount" class="form-control" placeholder="" required="">
    </div>
</div>
<div class="form-group">   
	 <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment_to"); ?></label>    
	 <div class="col-sm-8">        
	 	<input value="" type="text" name="payment_to" class="form-control" placeholder="" required="">    
	 </div>
</div>


