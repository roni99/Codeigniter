<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-primary box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('manage_product'); ?> </h3>
                    <div class="box-tools pull-right">
                         <a href="<?php echo base_url() ?>admin/product/list" type="submit" class="btn bg-primary btn-sm" style="color: white;"> <i class="fa fa-list"></i> <?php echo $this->lang->line('product_list'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                <div class="row">
                        <div class="col-md-9">
                             <form action="<?php echo base_url("admin/product/edit/".$product->id);?>" method="post" enctype="multipart/form-data" class="form-horizontal">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_name'); ?> </label>
                                        <input name="product_name" value="<?php print $product->name;?>" placeholder="<?php echo $this->lang->line('product_name'); ?> " class="form-control inner_shadow_green" required="" type="text">

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_url'); ?> </label>
                                        <input name="product_url" value="<?php print $product->url_generate;?>" placeholder="<?php echo $this->lang->line('product_url'); ?> " class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_qty'); ?> </label>
                                        <input name="product_qty" value="<?php print $product->quantity;?>" id="product_qty" placeholder="<?php echo $this->lang->line('product_qty'); ?> " class="form-control inner_shadow_green" maxlength="5" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_code'); ?> </label>
                                        <input name="product_code" value="<?php print $product->product_code;?>" placeholder="<?php echo $this->lang->line('product_code'); ?> " class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_price'); ?> </label>
                                        <input name="product_price" placeholder="<?php echo $this->lang->line('product_price'); ?>" value="<?php print $product->price;?>" id="product_price" maxlength="5" class="form-control inner_shadow_green" required="" type="text">
                                    </div>
                                </div>
                            </div>   
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_color'); ?> </label>
                                        <select name="product_color" class="form-control select2" data-placeholder="Select Color">

                                            <option value="<?php print $product->colors;?>" checked><?php print $product->colors;?></option>
                                            <option value="red">Red</option>
                                            <option value="green">Green</option>
                                            <option value="orange">Orange</option>
                                            <option value="black">Black</option>
                                            <option value="white">White</option>
                                        </select>
                                    </div>
                                </div>
                            </div>  
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_brand'); ?> </label>
                                       <input name="product_brand" value="<?php print $product->brand;?>" placeholder="<?php echo $this->lang->line('product_brand'); ?>" id="" class="form-control inner_shadow_green" required="" type="text">                                              
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_video_link'); ?> </label>
                                       <input name="product_video_link" value="<?php print $product_video_link->video_path;?>" placeholder="<?php echo $this->lang->line('product_video_link'); ?>" id=""  class="form-control inner_shadow_green" required="" type="text">                                              
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('product_size'); ?> </label>
                                       <select name="product_size[]" class="form-control select2" multiple="" data-placeholder="Select Size">
                                        <?php
                                        $selected_size = explode(",", $product->size);
                                        ?>
                                            <option value="small" <?php if(in_array("small", $selected_size)) echo"selected"; ?> >Small</option>
                                            <option value="medium" <?php if(in_array("medium", $selected_size)) echo"selected"; ?> >Medium</option>
                                            <option value="large" <?php if(in_array("large", $selected_size)) echo"selected"; ?> >Large</option>
                                            <option value="extra large" <?php if(in_array("extra large", $selected_size)) echo"selected"; ?> >Extra Large</option>
                                        </select>                                             
                                    </div>
                                </div>
                            </div> 
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label> <?php echo $this->lang->line('delivery_policy'); ?> </label>
                                        <select name="delivery_policy[]" class="form-control select2" multiple="" data-placeholder="Delivery Policy">
                                            <option value="">Select Size</option>
                                           <?php
                                            foreach ($all_delivery_policy as $delivery_policy_value){?>
                                               <option value="<?php echo $delivery_policy_value->id;?>" <?php if(in_array($delivery_policy_value->product_id, $select_product_delivary_policy_id)) echo "selected";?> > <?php echo $delivery_policy_value->area; ?></option>
                                           <?php } ?>
                                        </select>                                           
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <label><?php echo $this->lang->line('product_desc'); ?> </label>
                                        <textarea name="product_desc" class="form-control inner_shadow_green" required=""><?php print strip_tags($product->description);?></textarea>
                                    </div>
                                </div>
                            </div>

                             <div class="col-md-12">
                              <div class="form-group">
                                 <div class="col-sm-12">
                                <label><?php echo $this->lang->line('product_category');?></label><br>
                                 <?php
                                    foreach ($all_category as $category_value): ?>
                                <label>
                                  <input type="checkbox" name="category[]" value="<?php echo $category_value->id;?>" class="flat-red" <?php if(in_array($category_value->id, $select_product_category_id)) echo "checked";  ?> > <?php echo $category_value->name_en; ?> &nbsp;&nbsp;&nbsp;
                                </label>
                                 <?php endforeach ?>
                                </div>
                              </div>
                            </div>
                             <div class="col-md-12">
                                <div class="form-group">
                                    <center>
                                    <div class="col-sm-12">               
                                    <label> <?php echo $this->lang->line('product_thumbphoto'); ?> </label>
                                    <img id="thumb_photo" class="img-responsive thumb" src="<?php echo base_url().$product->thumb_photo;?>" alt="profile picture" style="max-width: 120px;">
                                    <br>
                                    <input type="file" name="product_thumbphoto" onchange="readpicture(this);" >
                                    </div>
                                    </center>
                                </div>
                            </div>
                           
                            <div class="col-md-12">
                              <div class="form-group">
                                <center>
                                    <button type="reset" class="btn btn-danger"><?php echo $this->lang->line('reset'); ?></button>
                                    <button type="submit" class="btn bg-aqua"><?php echo $this->lang->line('update'); ?></button>
                                </center>
                               </div>
                            </div>
                            
                            </form>
                        </div>
                    
                        <div class="col-md-3">
                            <!-- Product Image -->  
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <center>
                                        <label> <?php echo $this->lang->line('product_photo'); ?> </label> 
                                        <?php
                                            foreach ($select_product_photo as $select_photo) {
                                        ?>
                                        <img id="" class="img-responsive" src="<?php print base_url().$select_photo->photo;?>" alt="profile picture" style="max-width: 120px;">
                                        <a href="<?php echo base_url('admin/product_photo/'.$product->id.'/'.$select_photo->id) ?>" onclick = 'return confirm("Are You Sure?")' class="btn bg-maroon">Delete</a>
                                       <?php }?>
                                    </center>
                                </div><br>
                                <div class="col-sm-3">
                                    <form method="post" action="<?php print base_url('admin/product_photo/'.$product->id);?>" enctype="multipart/form-data" id="myform"> 
                                    
                                        <label> <?php echo $this->lang->line('upload_photo'); ?> </label> 

                                        <img id="product_photo" class="img-responsive" src="//placehold.it/400x400" alt="profile picture" style="max-width: 120px;">
                                        <br>
                                        <input type="file" name="product_photo" onchange="readpicture(this);" required="">
                                        <br>
                                         <input type="submit" class="btn btn-primary" value="Upload">
                                    
                                    </form>
                                </div>
                            </div>

                        </div>
                </div>
             </div>
        </div>
        <!-- /.box -->
    </div>
    <!--/.col (right) -->
</div>
</section>

<script>
// profile picture change
function readpicture(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('#thumb_photo')
        .attr('src', e.target.result)
        .width(100)
        .height(100);
    };
     reader.onload = function (e) {
        $('#product_photo')
        .attr('src', e.target.result)
        .width(100)
        .height(100);
    };

    reader.readAsDataURL(input.files[0]);
}
}
</script>

<script type="text/javascript">
$(document).ready(function(){
    $('[id^=product_price]').keypress(validateNumber);
     $('[id^=product_qty]').keypress(validateNumber);
});

function validateNumber(event) {
    var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 || event.keyCode === 46) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        return false;
    } else {
        return true;
    }
};    
</script>
<script>
  $(function () {  
    CKEDITOR.replace('product_desc')
    //$('.textarea').wysihtml5()
  })
 //Flat red color scheme for iCheck
$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
  checkboxClass: 'icheckbox_flat-green',
  radioClass   : 'iradio_flat-green'
})
</script>
