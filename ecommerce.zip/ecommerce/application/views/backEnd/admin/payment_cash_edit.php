<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("amount"); ?></label>
    <div class="col-sm-8">
        <input value="<?php echo $amount; ?>" type="text" name="amount" class="form-control" placeholder="">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment_to"); ?></label>    
    <div class="col-sm-8">        
    	<input value="<?php echo $remarks; ?>" type="text" name="payment_to" class="form-control" placeholder="">    
    </div>
</div>



