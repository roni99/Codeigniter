

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-danger box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('term_policy_add'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/term_policy/add" type="submit" class="btn bg-green btn-sm" style="color: white;"> <i class="fa fa-plus"></i> <?php echo $this->lang->line('term_policy_add'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <table id="userListTable" class="table table-bordered table-striped table_th_maroon">
                                <thead>
                                    <tr>
                                        <th style="width: 2%;"><?php echo $this->lang->line('sl'); ?></th>
                                        <th style="width: 20%;"><?php echo $this->lang->line('title'); ?></th>
                                        <th style="width: 60%;"><?php echo $this->lang->line('body'); ?></th>
                                        <th style="width: 8%;"><?php echo $this->lang->line('action');?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        foreach ($term_policy as $key => $value) {
                                            ?>
                                    <tr>
                                        <td> <?php echo ++$key ; ?> </td>
                                        <td> <?php echo character_limiter($value->title,20); ?> </td>
                                        <td> <?php echo character_limiter(strip_tags($value->body),150); ?> </td>
                                        <td> 
                                            <a href="<?php echo base_url('admin/term_policy/edit/'.$value->id); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i></a>
                                            <a href="<?php echo base_url('admin/term_policy/delete/'.$value->id); ?>" class="btn btn-sm btn-danger" onclick = 'return confirm("Are You Sure?")'><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                        }
                                        ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.col -->
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>


<script type="text/javascript">
    $(function () {
      $("#userListTable").DataTable();
    });
    
</script>


