<section class="content">
	<div class="row">
		<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
			
		</div>
		<div class="col-lg-6 col-md-8 col-sm-10 col-xs-10">
			
			<center>
				<i class="fa fa-check" aria-hidden="true" style="color: green; font-size: 250px; border-radius: 50%; border: 1px solid lightgreen; padding: 10px;"></i>
			</center>

		</div>
		<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
			
		</div>
	</div>
	<div class="row">
		<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
			
		</div>
		<div class="col-lg-6 col-md-8 col-sm-10 col-xs-10">

			<center >
			 <?php echo $noteMessage ; ?>   
			</center>

		</div>
		<div class="col-lg-3 col-md-2 col-sm-1 col-xs-1">
			
		</div>
	</div>
</section>