

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-danger box-solid">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo $this->lang->line('term_policy_edit'); ?> </h3>
                    <div class="box-tools pull-right">
                        <a href="<?php echo base_url() ?>admin/term_policy/list" type="submit" class="btn bg-green btn-sm" style="color: white;"> <i class="fa fa-plus"></i> <?php echo $this->lang->line('term_policy_list'); ?> </a>
                    </div>
                </div>
                <div class="box-body">
                    <div class="row">
                        <form action="<?php echo base_url("admin/term_policy/edit/".$edit_info->id);?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                            <br><br>
                            <div class="col-md-12">
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('title'); ?></label>
                                            <input name="title" placeholder="<?php echo $this->lang->line('title'); ?>" value="<?php print $edit_info->title;?>" class="form-control inner_shadow_red" required="" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-10">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <label><?php echo $this->lang->line('body') ?></label>
                                            <textarea name="body" placeholder="<?php echo $this->lang->line('body'); ?>" class="form-control inner_shadow_red" required="">
                                                <?php print $edit_info->body;?>
                                            </textarea>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="col-md-12">
                                <center>
                                    <button type="reset" class="btn bg-aqua"><?php echo $this->lang->line('reset') ?></button>
                                    <button type="submit" class="btn btn-white "><?php echo $this->lang->line('update') ?></button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- /.box -->
        </div>
        <!--/.col (right) -->
    </div>
</section>

<script type="text/javascript">
    $(function () {
    CKEDITOR.replace('body') ;
  });
</script>

