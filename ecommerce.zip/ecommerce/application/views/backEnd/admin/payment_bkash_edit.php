
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("transaction_id"); ?></label>
    <div class="col-sm-8">
        <input value="<?php echo $bkash_info->transaction_id; ?>" type="text" name="transaction_id" class="form-control" placeholder="<?php echo $this->lang->line("transaction_id"); ?>">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("sender"); ?></label>
    <div class="col-sm-8">
        <input value="<?php echo $bkash_info->sender; ?>" type="text" name="sender" class="form-control" placeholder="<?php echo $this->lang->line("sender"); ?>">
    </div>
</div>
<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("amount"); ?></label>
    <div class="col-sm-8">
        <input value="<?php echo $amount; ?>" type="number" step="0.01" name="amount" class="form-control" placeholder="<?php echo $this->lang->line("amount"); ?>">
    </div>
</div>
<div class="form-group">    
    <label for="inputPassword3" class="col-sm-2 control-label"><?php echo $this->lang->line("payment_to"); ?></label>    
    <div class="col-sm-8">        
        <input value="<?php echo $remarks; ?>" type="text" name="payment_to" class="form-control" placeholder="">    
    </div>
</div>

