
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <?php
            if($this->session->flashdata('messages')){
        ?>
            <h3 style="margin-left: 20px;"><?php print $this->session->flashdata('messages');?></h3>
        <?php }?>
        <section >
            <!-- <div class="jumbotron text-center">
                <h1>HRSOFTBD MASTER ADMIN</h1>
                <p>Admin / User</p> 
            </div> -->
            <h4 style="margin-left: 10px;"><a href=" <?php echo base_url(''); ?>"> Home</a></h4>
            <h3 align="center">Product List</h3>
            
        </section>

        <section >
              <?php $this->load->view($page); ?>
        </section>
       
        <footer style="margin-top: 60px;">

            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <h3>Column 1</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
                    </div>
                    <div class="col-sm-4">
                        <h3>Column 2</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
                    </div>
                    <div class="col-sm-4">
                        <h3>Column 3</h3>        
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
                    </div>
                </div>
            </div>
        </footer>

    </body>
</html>
