<div class="container">
	<p align="right" style="margin-right: 20px;">
		<a href="<?php echo base_url('News/cart_list');?>">Cart List: Total <?php 
		$a=0;
		$cart = $this->cart->contents();
			//print '<pre>'; print_r($cart);die;
		foreach ($cart as $values) {
			$a = $a + $values['qty'];
		}
		echo $a;
		?> 
		Products</a>
	</p>
    <div class="row">
        <div class="col-md-4">
        <form method="post" action="<?php echo base_url('News/payment/pay'); ?>" enctype="multipart-form/data">
            <div class="form-group">
                <label>Payment Method</label>
                <select name="payment_method" class="form-control" required="">
                    <option value="">Select One</option>
                    <option value="1">COD</option>
                    <option value="2">Bkash</option>
                    <option value="3">Roket</option>
                    <option value="4">Bank</option>
                </select>
            </div>
            <div class="form-group">
                <label>Remarks</label>
                <input type="text" name="remarks" class="form-control" value="" required="">
            </div>
            <div class="form-group">
                <button class="form-control">Submit</button>
            </div>
        </form>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-6" style="border: 1px solid black;min-height: 200px;">
                <table class="table table-border">
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                    <?php 
                    $cart = $this->cart->contents();
                    foreach ($cart as $key => $value) {
                    ?>
                    <tr>
                        <td>
                            <img src="<?php print base_url().$value['image'];?>" width="50px" height="50px  ">
                        </td>
                        <td>
                            <p><?php print $value['name'];?></p>
                        </td>
                        <td>
                            <?php echo $value['price']; ?>
                        </td>
                        <td>
                            <p> Quantity : <?php echo $value['qty']; ?></p>
                        </td>
                        <td>
                            <a href="<?php echo base_url('News/cart_delete/'.$value['rowid']); ?>" onclick='return confirm("Are you Sure?");'>Delete</a>
                        </td>
                    </tr>
                
                    <?php }?>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td align=""><b>Total </b>: <?php echo $this->cart->total(); ?> .TK</td>
                    </tr>
                </table>
        </div>
    </div>
</div>

<style type="text/css">
	.product{
	  border: 1px solid black;
	  margin: 2px;
	}
</style>