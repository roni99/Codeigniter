<div class="container">
	<p align="right" style="margin-right: 20px;">
		<a href="<?php echo base_url('News/cart_list');?>">Cart List: Total <?php 
		$a=0;
		$cart = $this->cart->contents();
		//	print '<pre>'; print_r($cart);die;
		foreach ($cart as $values) {
			$a = $a + $values['qty'];
		}
		echo $a;
		?> 
		Products</a>
	</p>
    <div class="row">
    	<?php 
    	//print '<pre>'; print_r($products);
    	foreach ($products as $key => $value) {
    	?>
        <div class="col-md-3 product">
        	<img src="<?php print base_url().$value->thumb_photo;?>" width="200px" height="200px	">
        	<h4><?php print $value->name;?></h4>
        	<p>Product Code : <?php echo $value->product_code; ?></p>
        	<p> Quantity : <?php echo $value->quantity; ?></p>
        	<form method="post" action="<?php echo base_url('News/add_cart');?>">
        	<input type="hidden" name="id" value="<?php echo $value->id; ?>">
        	<input type="number" name="qty" minlength="1" maxlength="10" value="1" style="width: 20%;display: inline-block;" class="form-control">
        	<button type="submit" class="btn btn-success">Add to Cart</button>
        	</form>
        </div>
        <div class=""></div>
    	<?php }?>
    </div>
</div>

<style type="text/css">
	.product{
	  border: 1px solid black;
	  margin: 2px;
	}
</style>