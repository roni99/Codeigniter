<div class="container">
	<p align="right" style="margin-right: 20px;">
		<a href="<?php echo base_url('News/cart_list');?>">Cart List: Total <?php 
		$a=0;
		$cart = $this->cart->contents();
			//print '<pre>'; print_r($cart);die;
		foreach ($cart as $values) {
			$a = $a + $values['qty'];
		}
		echo $a;
		?> 
		Products</a>
	</p>
    <div class="row">
        <div class="col-md-4">
        <form method="post" action="<?php echo base_url('News/registration/customer_login'); ?>" enctype="multipart-form/data">
            <div class="form-group">
                <label>Enter Email</label>
                <input type="email" class="form-control" name="email" value="" required="">
            </div>
            <div class="form-group">
                <label>Enter Password</label>
                <input type="password" name="password" class="form-control" value="" required="">
            </div>
            <div class="form-group">
                <button class="form-control">Submit</button>
            </div>
        </form>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-6" style="border: 1px solid black;min-height: 200px;">
            <h3>Registration Here........</h3>
        </div>
    </div>
</div>

<style type="text/css">
	.product{
	  border: 1px solid black;
	  margin: 2px;
	}
</style>