<div class="container">
	<p align="right" style="margin-right: 20px;">
		<a href="<?php echo base_url('News/cart_list');?>">Cart List: Total <?php 
		$a=0;
		$cart = $this->cart->contents();
		//print '<pre>'; print_r($cart);die;
		foreach ($cart as $values) {
			$a = $a + $values['qty'];
		}
		echo $a;
		?> 
		Products</a>
	</p>
    <table class="table table-border">
        <tr>
            <th>Photo</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Action</th>
        </tr>
    	<?php 
    	$cart = $this->cart->contents();
    	foreach ($cart as $key => $value) {
    	?>
        <tr>
            <td>
                <img src="<?php print base_url().$value['image'];?>" width="60px" height="60px  ">
            </td>
            <td>
                <h4><?php print $value['name'];?></h4>
            </td>
            <td>
                <?php echo $value['price']; ?>
            </td>
            <td>
                <p> Quantity : <?php echo $value['qty']; ?></p>
            </td>
            <td>
                <a href="<?php echo base_url('News/cart_delete/'.$value['rowid']); ?>" onclick='return confirm("Are you Sure?");'>Delete</a>
            </td>
        </tr>
    
    	<?php }?>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td align=""><b>Total </b>: <?php echo $this->cart->total(); ?> .TK</td>
        </tr>
    </table>
    <a href="<?php echo base_url('News/registration'); ?>"><button class="btn btn-primary" style="float: right;">Order</button></a>
</div>

<style type="text/css">
	.product{
	  border: 1px solid black;
	  margin: 2px;
	}
</style>