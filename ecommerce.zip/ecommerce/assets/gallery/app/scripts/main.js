$(document).ready(function(){
    var $gallery = $('.gallery');

    $gallery.vitGallery({
        autoplay: true
    })
})